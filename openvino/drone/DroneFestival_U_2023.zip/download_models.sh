#!/bin/bash

omz_downloader --name googlenet-v4-tf
omz_converter --name googlenet-v4-tf
