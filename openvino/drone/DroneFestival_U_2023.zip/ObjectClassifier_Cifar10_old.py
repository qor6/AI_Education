# 필요한 모듈들을 로드합니다.
import sys
from openvino.runtime import Core
import cv2
import os
import threading
import time
import traceback


# Cifar10 모델을 사용하는 ObjectClassifier 모듈입니다.
class ObjectClassifier_Cifar10():
    '''
    device : 추론에 사용할 device종류 CPU,GPU,MYRIAD 중 하나를 선택합니다.
    getFrameFunc : 추론에 사용할 이미지데이터를 가져오는 함수입니다. 이미지데이터를 return하는 함수가 필요합니다.
    '''

    def __init__(self, device, getFrameFunc):
        self.getFrameFunc = getFrameFunc
        self.originFrame = None  # 추론하는 이미지 대상입니다.

        # model의 xml파일입니다.
        model_xml = './models/cifar_0.xml'
        # xml파일명으로부터 bin파일명을 구성합니다.
        model_bin = os.path.splitext(model_xml)[0] + ".bin"
        # cpu사용시 추가될 플러그인입니다. 이 경로는 linux기반으로 작성되었으며 windows에서 실행하려면 알맞게 고쳐줘야합니다.
        cpu_extension = '/opt/intel/openvino/inference_engine/lib/intel64/libcpu_extension_sse4.so'
        # Cifar10 모델의 output을 className으로 변환하기위한 문자열 리스트입니다.
        self.labels = ["airplane", "automobile", "bird", "cat", "deer", "dog", "frog", "horse", "ship", "truck",
                       "bottle", "face", "dummy"]
        # 추론엔진 네트워크를 xml,bin파일로 생성합니다.
        ie = Core()
        if cpu_extension and 'CPU' in device:
            ie.add_extension(cpu_extension, 'CPU')
        # 최종적으로 사용가능한 신경망네트워크를 로드합니다.
        net = ie.read_model(model=model_xml)
        self.exec_net = ie.compile_model(model=net, device_name=device)

        # 입력과 출력의 이름을 가져옵니다.
        self.input_blob = self.exec_net.input(0)
        self.out_blob = self.exec_net.output(0)

        # 입력 이미지의 크기를 저장합니다.
        n, c, self.h, self.w = self.input_blob.shape

        # 랜더링 스레드에서 사용할 변수들입니다.
        self.sortedClassifiedList = []  # 분류된 레이블들을 신뢰도순으로 정렬한 리스트입니다.
        self.infer_time = 0  # 추론하는데 걸린시간입니다.
        self.inferFPS = 15  # 1초에 몇번 추론을 진행할 것인지 입니다.

        # 추론을 반복하는 쓰레드를 생성합니다.
        processThread = threading.Thread(target=self.inferenceThread)  # inferenceThread 메소드로 쓰레드를 시작하도록 설정합니다.
        processThread.daemon = True  # 메인쓰레드가 종료되면 같이 종료되도록 합니다.
        processThread.start()  # 쓰레드를 시작합니다.

    # 추론을 진행하는 메소드입니다.
    def detect(self):
        # 추론할 이미지를 입력이미지 크기에 맞게 resize합니다.
        frame = cv2.resize(self.originFrame, (self.w, self.h))
        # 추론하기위해 사용할 blob 형식으로 만듭니다.
        blob = np.expand_dims(frame.transpose(2, 0, 1), 0)

        # 추론 시작 시간을 담습니다.
        infer_start = time.time()
        # 실행가능한 신경망으로 추론을 시작합니다.
        res = self.exec_net([blob])[self.out_blob]
        # 추론 시작시간과 현재시간의 차로 추론하는데 소요된 시간을 계산합니다.
        self.infer_time = time.time() - infer_start

        # 이전에 검출된 정보를 지웁니다.
        self.sortedClassifiedList.clear()
        # 신뢰도순서대로 정렬한 인덱스리스트를 구합니다.
        sortedList = sorted(range(len(res[0])), key=lambda i: res[0][i], reverse=True)
        for idx in sortedList:
            self.sortedClassifiedList.append(
                (idx, res[0][idx]))  # 정렬된 인덱스대로 최종결과를 구성합니다. 리스트의 요소는 (레이블인덱스, 신뢰도값) 으로 구성됩니다.

    # 쓰레드가 시작하는 메소드입니다.
    def inferenceThread(self):
        while True:  # 무한반복
            frame = self.getFrameFunc()  # 이미지를 받아옵니다.
            if frame is not None:  # 이미지가 None이 아니면
                try:
                    self.originFrame = frame.copy()  # 받은 이미지를 추론에 사용할 이미지에 복사합니다.
                    self.detect()  # 추론
                    time.sleep(1.0 / self.inferFPS)  # 추론FPS에 따라 적당히 쉬어줍니다.

                except Exception as error:  # 예외처리부분입니다.
                    print(error)
                    traceback.print_exc()
                    print("catch error")

    # 외부에서 추론결과를 받기위한 메소드입니다.
    def getProcessedData(self):
        return self.infer_time, self.sortedClassifiedList  # 추론시간과 추론결과물을 return합니다.

    # 추론 속도를 새롭게 설정하는 메소드입니다.
    def setInferFPS(self, newFPS):
        self.inferFPS = newFPS

