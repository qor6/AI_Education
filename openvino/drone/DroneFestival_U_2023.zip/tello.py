# ver 2019.07.16 20:30
# latest update : [Time out]
# 필요한 모듈들을 임포트합니다.
import socket
import threading
import traceback
import time
import cv2

class Tello(): # Tello드론과 직접적으로 통신하는 클래스입니다.
    def __init__(self, loggingFunc, stateReceiveFunc):
        self.stateReceiveFunc = stateReceiveFunc # GUI쪽에 Tello의 state를 업데이트하라는 함수입니다.
        self.loggingFunc = loggingFunc # GUI쪽에서 logging을 위한 함수입니다.
        # 컨트롤러 프로그램이 Tello로 명령을 내리기위해 바인딩할  ip와 port, 소켓입니다.
        self.local_main_ip = '192.168.10.2'
        self.local_main_port = 8889
        self.socket = None
        # Tello로부터 state값을 받기위한 ip와 port, 소켓입니다.
        self.local_state_ip = "0.0.0.0"
        self.local_state_port = 8890
        self.socket_state = None
        # Tello와 직접연결했을 때 Tello의 고유주소와 포트입니다.
        self.tello_address = ('192.168.10.1', 8889)
        # Tello로부터 영상스트리밍을 받기위한 ip:port, opencv의 VideoCapture입니다.
        self.videoInput = 'udp://0.0.0.0:11111'
        self.videoInput = 0 # cam
        self.cap = None
        # VideoCapture가 정상적으로 통신했는지의 여부입니다.
        self.binitialized = False
        # Tello에게 지속적으로 ‘command’명령을 내려주는 스레드를 멈추기위한 플래그입니다.
        self.DoNotLandThreadStopFlag = False

    # Tello드론에게 전달받은 명령어를 전송하는 함수입니다.
    def send_command(self, command):
        if self.socket is None: # 소켓이 준비되지않았다면
            self.loggingFunc('Not connected')
            return False
        else: # 준비되었다면
            try:
                self.socket.sendto(command.encode('utf-8'), self.tello_address) # utf-8로 인코딩하여 Tello드론으로 송신합니다.
                self.loggingFunc('sending command: %s to %s' % (command, self.tello_address[0]))
                return True
            except Exception as error:
                traceback.print_exc()
                print("catch error")

    # Tello드론으로부터 지속적으로 응답을 수신을 하는 함수입니다.
    def receive_process(self):
        while True:
            if self.socket is not None:
                try:
                    response, ip = self.socket.recvfrom(1024) # 응답을 받습니다.
                    self.response = response.decode('utf-8') # 디코딩하여 문자열로 만듭니다.
                    self.loggingFunc('응답 : %s' % self.response)
                except Exception as exc:
                    traceback.print_exc()
                    print("catch error")
    # Tello드론으로부터 지속적으로 상태값을 수신하는 함수입니다.
    def receive_state_process(self):
        while True:
            if self.socket_state is not None:
                try:
                    response, ip = self.socket_state.recvfrom(2048) # 응답을 받습니다.
                    stateDict = self.stateReceiveFunc(response) # 상태수신함수를 호출합니다.
                except socket.error as exc:
                    print("Caught exception socket.error : %s" % exc)
                    return
    # VideoCapture로부터 다음 프레임 이미지를 반환하는 함수입니다.
    def readFrame(self):
        if self.cap is None:
            return None
        else:
            ret, frame = self.cap.read()
            if ret:
                return frame
            else:
                return None

    # Tello드론과 연결을 시도합니다.
    def tryConnect(self):
        try:
            if self.videoInput != 0:
                # 네트워크 통신을 담당할 UDP소켓을 준비합니다.
                self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR,1)
                self.socket.bind((self.local_main_ip, self.local_main_port))
                self.loggingFunc("Main socket binding ip : " + self.local_main_ip + ":" + self.local_main_port.__str__())
                print(("Main socket binding ip : " + self.local_main_ip + ":" + self.local_main_port.__str__()))

                # 응답을 수신하는 쓰레드를 시작합니다.
                self.receive_thread = threading.Thread(target=self.receive_process)
                self.receive_thread.daemon = True
                self.receive_thread.start()

                # 상태정보를 수신하는 UDP소켓을 준비합니다.
                self.socket_state = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                self.socket_state.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR,1)
                self.socket_state.bind((self.local_state_ip, self.local_state_port))
                self.loggingFunc("State socket binding ip : " + self.local_state_ip + ":" + self.local_state_port.__str__())
                print("State socket binding ip : " + self.local_state_ip + ":" + self.local_state_port.__str__())

                # 상태정보를 수신하는 쓰레드를 시작합니다.
                self.receive_state_thread = threading.Thread(target=self.receive_state_process)
                self.receive_state_thread.daemon = True
                self.receive_state_thread.start()

                # 최초로 다음 명령어들을 송신합니다.
                self.send_command("command") # Tello SDK 명령어로 제어할 수 있게 하는 명령어입니다.
                self.send_command("streamon") # Tello가 스트리밍을 시작하게 만드는 명령어입니다.
                self.send_command("battery?") # 현재 Tello드론의 베터리상태를 요청하는 명령어입니다.

                # 지속적으로 command 명령어를 보내주는 쓰레드를 시작합니다. 이 쓰레드가 없으면 15초동안 드론을 조종하지않으면 자동착륙합니다.
                self.doNotLand = threading.Thread(target=self.DoNotLand)
                self.doNotLand.daemon = True
                self.doNotLand.start()

            self.binitialized = False
            # VideoCapture로 Tello와 통신을 시작하는 쓰레드를 시작합니다.
            th = threading.Thread(target=self.initVideoCapture)
            th.daemon = True
            th.start()
            # VideoCapture가 제대로 통신을 하고있는지를 확인하는 쓰레드를 시작합니다.
            th2 = threading.Thread(target=self.videoCaptureCheck)
            th2.daemon = True
            th2.start()

            return True
        except Exception as error: # 만약 모종의 이유로 실패한다면 변수를 초기화합니다.
            traceback.print_exc()
            self.DoNotLandThreadStopFlag = True
            self.socket = None
            self.socket_state = None
            self.cap = None
            self.loggingFunc(error.__str__())
            print("catch error")
            return False

    # Tello드론과 연결을 해제하는 함수입니다.
    def disconnect(self):
        self.DoNotLandThreadStopFlag = True # command명령어를 지속적으로 보내주는 함수를 종료하게끔합니다.
        if self.socket is not None:
            self.send_command('streamoff') # 스트리밍을 끄도록 명령어를 보냅니다.
            time.sleep(0.1) # 명령어를 처리할동안 기다립니다.
            self.socket.close() # 소켓을 닫습니다.
        self.socket = None
        if self.socket_state is not None:
            self.socket_state.close() # 상태수신소켓을 닫습니다.
        self.socket_state = None
        if self.cap is not None:
            self.cap.release() # VideoCapture를 Release합니다.
        self.cap = None

    # Tello드론에게 지속적으로 command 명령어를 보내주는 함수입니다.
    def DoNotLand(self):
        self.DoNotLandThreadStopFlag = False
        while True:
            if self.DoNotLandThreadStopFlag: # 외부에서 그만보내라는 신호가 있다면
                self.DoNotLandThreadStopFlag = False
                self.loggingFunc("자동착륙방지시스템 종료")
                break # while문을 빠져나가 함수가 종료됩니다.
            if not self.send_command('command'): # command 명령어를 보내고 만약 송신하지 못했다면 자동으로 함수를 종료합니다.
                self.loggingFunc("드론과 연결이 끊어진 것 같습니다. 자동착륙방지시스템을 종료합니다.")
                break
            time.sleep(10) # 10초마다 보내도록 합니다.
    
    # VideoCapture를 초기연결하는 함수입니다.
    def initVideoCapture(self):
        self.loggingFunc('initVideoCapturing...')
        self.cap = cv2.VideoCapture(self.videoInput) # Tello드론과 연결을 시도합니다. 연결이 된다면 다음 라인으로 넘어갑니다.
        self.binitialized = True # 연결완료된 상태로 변경합니다.

    # VideoCapture가 제대로 연결됐는지 확인하는 함수입니다.
    def videoCaptureCheck(self):
        initStartTime = time.time() # 연결시작시간을 저장합니다.
        while not self.binitialized: # 연결완료되지않았으면 
            dt = time.time() - initStartTime # 시간이 얼마나 지났는지 확인합니다.
            if dt >= 10.0: # 만약 10초가 흘렀다면
                self.loggingFunc("[Timeout] 영상스트리밍 수신을 실패했습니다. - 시간초과") # 10초를 넘겼다고 로그를 띄웁니다.
                break
