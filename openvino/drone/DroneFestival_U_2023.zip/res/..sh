#!/bin/bash
cp 1.jpg .1.jpg
cp 2.jpg .2.jpg
cp 3.jpg .3.jpg
cp 4.jpg .4.jpg
cp 5.jpg .5.jpg
cp 6.jpg .6.jpg
cp 7.jpg .7.jpg
cp 8.jpg .8.jpg
echo "done"
