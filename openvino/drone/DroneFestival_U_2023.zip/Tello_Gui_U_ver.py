# -*- coding: utf-8 -*-

# 필요한 모듈들을 로드합니다.
from PyQt5 import QtCore, QtGui, QtWidgets
import tello
import cv2
import traceback
import datetime
import threading
import os
import time
import mobilenet_label

# Dialog UI를 관리하는 클래스입니다. UI생성부터 상호작용까지 모든것을 관장합니다.
class Ui_Dialog(object):
    # 생성자의 매개변수로 Dialog(객체)와 device(문자열), 사물검출여부(bool)를 받습니다. 
    def __init__(self, Dialog, device, bObjectDetection):
        # Dialog UI를 구성합니다.
        self.setupUi(Dialog)
        # Dialog UI 내 버튼이나 입력 등에 대한 상호작용을 하는 함수를 설정합니다.
        self.bindFuncs()
        
        # 로깅을 위한 변수들입니다.
        self.logBuffer = [] # 로깅될 데이터버퍼입니다.
        self.logWriteTimer = QtCore.QTimer() # 로그를 갱신하기위해 타이머를 사용합니다.
        self.logWriteTimer.timeout.connect(self.logWriter) # 시간이 되었을때 self.logWriter를 호출하도록 설정합니다.
        self.logWriteTimer.start(10) # 타이머를 10ms로 설정하고 시작합니다.

        # 드론 컨트롤 관련 변수들입니다.
        self.delta_height=20 # 드론이 상하로 한번 움직일 때의 거리값입니다.(cm)
        self.delta_rotate=45 # 드론이 시계/반시계 방향으로 한번 회전할 때의 거리값입니다.(cm)
        self.delta_LR=20 # 드론이 좌우로 한번 움직일 때의 거리값입니다.(cm)
        self.delta_FB=20 # 드론이 앞뒤로 한번 움직일 때의 거리값입니다.(cm)
        #tello로부터 수신하는 상태값들을 담는 딕셔너리입니다.
        self.stateDict = {
            "pitch": "0",
            "roll": "0",
            "yaw": "0",
            "vgx": "0",
            "vgy": "0",
            "vgz": "0",
            "templ": "0",
            "temph": "0",
            "tof": "0",
            "h": "0",
            "bat": "0",
            "baro": "0.0",
            "time": "0",
            "agx": '0.0',
            "agy": '0.0',
            "agz": '0.0',
            "wifi": '99'
        }


        ###### 시간측정 관련 변수들입니다.
        self.picRenderW = 100 # 캡쳐한 이미지를 UI에 표시할 가로크기
        self.picRenderH = 100 # 캡쳐한 이미지를 UI에 표시할 세로크기
        self.Qt_pics = [] # 캡쳐된 이미지가 그려질 Qt위젯들입니다.
        self.Qt_picTimes = [] # 캡쳐된 시간을 표시할 Qt위젯들입니다.
        self.picDateTime = [None]*8 # 캡쳐된 시간을 저장할 리스트입니다.
        self.timerStartTime = None # 첫 이미지가 검출된 시간입니다.
        self.latestDetectedLabel = '' # 마지막으로 검출된 사물 레이블(이름)입니다.
        self.prevFrameLabelIdx = -1 # 이전 프레임의 사물 레이블 인덱스입니다.
        self.CLASSIFICATION_FRAME_RECT_PERCENT = 10 # 전체프레임에서 가장자리를 10%만큼 제거한 이미지로 추론합니다.
        self.CLASSIFICATION_CONF = 0.5 # 분류신뢰도 임계값입니다. 이 값을 넘겨야 해당 사물이라고 판단합니다.
        self.CLASSIFICATION_FRAME = 10 # 얼마나 연속되서 검출되어야 확신하는지에 대한 값입니다.
        self.sameDetectionFrameCount = 0 # 같은 사물이 몇번이나 연속해서 검출되었는지의 횟수입니다.

        self.Qt_pics.append(self.P1) # 캡쳐된 이미지가 그려질 Qt위젯입니다.
        self.Qt_pics.append(self.P2) # 캡쳐된 이미지가 그려질 Qt위젯입니다.
        self.Qt_pics.append(self.P3) # 캡쳐된 이미지가 그려질 Qt위젯입니다.
        self.Qt_pics.append(self.P4) # 캡쳐된 이미지가 그려질 Qt위젯입니다.
        self.Qt_pics.append(self.P5) # 캡쳐된 이미지가 그려질 Qt위젯입니다.
        self.Qt_pics.append(self.P6) # 캡쳐된 이미지가 그려질 Qt위젯입니다.
        self.Qt_pics.append(self.P7) # 캡쳐된 이미지가 그려질 Qt위젯입니다.
        self.Qt_pics.append(self.P8) # 캡쳐된 이미지가 그려질 Qt위젯입니다.
        self.Qt_picTimes.append([self.P1_1,self.P1_2,self.P1_3]) # 캡쳐된 시간을 표시할 Qt위젯입니다.
        self.Qt_picTimes.append([self.P2_1,self.P2_2,self.P2_3]) # 캡쳐된 시간을 표시할 Qt위젯입니다.
        self.Qt_picTimes.append([self.P3_1,self.P3_2,self.P3_3]) # 캡쳐된 시간을 표시할 Qt위젯입니다.
        self.Qt_picTimes.append([self.P4_1,self.P4_2,self.P4_3]) # 캡쳐된 시간을 표시할 Qt위젯입니다.
        self.Qt_picTimes.append([self.P5_1,self.P5_2,self.P5_3]) # 캡쳐된 시간을 표시할 Qt위젯입니다.
        self.Qt_picTimes.append([self.P6_1,self.P6_2,self.P6_3]) # 캡쳐된 시간을 표시할 Qt위젯입니다.
        self.Qt_picTimes.append([self.P7_1,self.P7_2,self.P7_3]) # 캡쳐된 시간을 표시할 Qt위젯입니다.
        self.Qt_picTimes.append([self.P8_1,self.P8_2,self.P8_3]) # 캡쳐된 시간을 표시할 Qt위젯입니다.
        self.picLabels = ['dog', 'scissors', 'rock', 'paper', 'horse', 'LG', 'KISTI', 'Intel'] # 검출할 사물들의 레이블들입니다.

        ######

        ### 스크립트 관련 변수입니다.
        self.bOrdering = False # 스크립트가 진행중인지의 값입니다.
        self.bOrderPause = False # 스크립트가 일시정지상태인지의 값입니다.
        ###

        self.tello = tello.Tello(self.log, self.stateReceive) # Tello 드론과 직접적으로 통신을 해주는 객체입니다. 로깅함수와 상태값을 받는 함수를 전달인자로 넘겨줍니다.
        self.updateIP() # tello객체 내부에서 통신을 위해 사용하는 localIP를 업데이트해줍니다.


        # 드론으로부터 받은 이미지를 담는 변수
        self.originFrame = None
        # 추론을 하기위한 이미지를 담는 변수
        self.inferFrame = None

        # 검출여부옵션 저장
        self.bObjectDetection = bObjectDetection
        if self.bObjectDetection: # 검출해야한다면
            print('Object Detector initialize...')
            # OpenVINO 임포트
            from ObjectClassifier_Cifar10 import ObjectClassifier_Cifar10
            # ObjectClassifier 인스턴스를 만듭니다.
            self.objClassifier = ObjectClassifier_Cifar10(device, self.getInferFrame) # 받은 device문자열과 originFrame을 리턴하는 함수를 전달합니다.
        self.requestSNR = False # 드론으로 wifi SNR을 요청했는지 여부입니다.

        self.button_on_off(False) # 드론을 움직이는 버튼들을 비활성화합니다.
        self.resetDetectionInfo() # 검출정보를 초기화합니다.

    # 10ms마다 호출되는 함수입니다.
    def logWriter(self):
        self.updateImage() # UI에 이미지, 추론결과를 업데이트합니다.
        for logStr in self.logBuffer: # 로그버퍼에 있는 내용들을 로그창에 표시합니다.
            self.loglist.append(logStr)
        if len(self.logBuffer) > 0: # 표시된 로그가 있으면
            self.loglist.verticalScrollBar().setValue(self.loglist.verticalScrollBar().maximum()) #로그창의 스크롤바를 맨 아래로 내려줍니다.
            self.logBuffer.clear() # 로그버퍼를 비웁니다.
        self.updateState() # 드론의 상태를 UI에 업데이트합니다.
    # 외부에서 호출하여 로깅을 요청할 수 있는 함수입니다.
    def log(self, logStr):
        logStr = logStr.strip() # 문자열 양끝에 개행이나 공백을 지워줍니다.
        self.logBuffer.append(logStr) # 로그버퍼에 추가합니다.
    # Tello객체가 이 함수를 부릅니다. stateData에 문자열형식으로 state정보가 담깁니다.
    def stateReceive(self, stateData):
        stateData = stateData.decode('utf-8') # utf-8로 디코딩합니다.
        states = stateData.split(';')[:-1] # state들의 구분을 ;로 하므로 split합니다.
        for state in states:
            keyValue = state.split(':')# state는 :로 값명칭과 값이 들어있습니다. 마찬가지로 split해줍니다.
            key = keyValue[0] # 값명칭입니다.
            value = keyValue[1] # 값입니다.
            self.stateDict[key] = value # 상태정보를 담는 딕셔너리에 담습니다.
        return self.stateDict # 상태정보를 리턴합니다. 당장은 사용하지 않습니다.
    #드론 UI에 상태를 갱신하는 함수입니다.
    def updateState(self):
        self.TOF.setText(self.TOF_TextFormat % int(self.stateDict['tof'])) # TOF 업데이트
        self.Height.setText(self.HeightTextFormat % int(self.stateDict['h'])) # Height 업데이트
        sec = int(self.stateDict['time']) # Flight Time을 가져와서
        hour = int(sec / 3600) # 시간을 구하고
        sec = sec - hour * 3600 # 시간을 뺀 나머지 초로
        minute = int(sec / 60) # 분을 구합니다.
        sec = sec - minute * 60 # 분을 뺀 초를 구합니다.
        self.F_Time.setText(self.F_TimeTextFormat % (hour, minute, sec)) # 시간:분:초 로 업데이트합니다.
        self.temp.setText(self.tempTextFormat % (int(self.stateDict['templ']), int(self.stateDict['temph']))) #temp low와 temp high를 업데이트합니다.
        self.Battery.setProperty("value", int(self.stateDict['bat'])) # 베터리의 상태를 업데이트합니다.
        if self.requestSNR: # 만약 SNR을 요청한 상태면
            try:
                wifi_SNR = int(self.tello.response) # 드론으로부터 마지막 수신한 데이터를 SNR값으로 가정합니다.
                self.wifi_snr.setProperty('value', wifi_SNR) # SNR값을 업데이트합니다.
                self.requestSNR = False # SNR을 요청하지 않은 상태로 변경합니다.
            except:
                pass
    # 드론이미지와 추론결과를 UI에 보여주는 함수입니다.
    def updateImage(self):
        renderingW = 600 # UI에 랜더링될 가로크기입니다.
        renderingH = 450 # UI에 랜더링될 세로크기입니다.
        try:
            if self.tello.cap is not None: # tello모듈이 이미지를 수신중이면
                w = self.getCapW() # 수신한 이미지의 가로크기를 가져옵니다.
                h = self.getCapH() # 수신한 이미지의 세로크기를 가져옵니다.
                cutW = w*self.CLASSIFICATION_FRAME_RECT_PERCENT/100 # 원본이미지에서 잘라낼 가로크기를 구합니다.
                cutH = h*self.CLASSIFICATION_FRAME_RECT_PERCENT/100 # 원본이미지에서 잘라낼 세로크기를 구합니다.
                cut_rect = (int(cutW), int(cutH), int(w-cutW), int(h-cutH)) # 잘라낼 rect를 구합니다.
                self.originFrame = self.tello.readFrame() # tello모듈로부터 마지막 프레임을 가져옵니다.

                if self.originFrame is not None: # 프레임에 문제가 없다면
                    self.inferFrame = self.originFrame[cut_rect[1]:cut_rect[3],cut_rect[0]:cut_rect[2]] # 추론에 사용할 이미지를 잘라낼 rect를 이용해 만듭니다.
                    renderImg = cv2.cvtColor(self.originFrame, cv2.COLOR_BGR2RGB) # 색상채널을 BGR에서 RGB로 바꿉니다.
                    
                    # 모두 검출하였는지 체크
                    bFishedAllObjDetection = True
                    for dateTime in self.picDateTime:
                        if dateTime is None: # 하나라도 날짜가 비어있다면
                            bFishedAllObjDetection = False # 모두 검출한 상태가 아님
                            break
                    if bFishedAllObjDetection: # 모두 검출된 상태라면
                        timerDateTime = self.picDateTime[len(self.picDateTime)-1] - self.picDateTime[0] # 총 걸린시간 계산
                        allSec = timerDateTime.seconds # 초 단위로 들고옵니다.
                        minute = int(allSec/60) # 분을 구합니다.
                        sec = allSec - minute*60 # 분을 뺀 초를 구합니다.
                        self.T1.display(minute) # UI에 분을 보여줍니다.
                        self.T2.display(sec) # UI에 초를 보여줍니다.
                        self.T3.display(int(timerDateTime.microseconds/10000)) # UI에 밀리초를 보여줍니다.
                    elif self.picDateTime[0] is not None: # 모두검출하진않았지만 첫번째 이미지를 검출한 경우
                        if self.timerStartTime is None: # 시작시간이 저장안됐다면
                            self.timerStartTime = self.picDateTime[0] # 첫번째이미지 시간을 대입합니다.
                        timerDateTime = datetime.datetime.now() - self.timerStartTime # 현재까지 걸린 시간을 계산합니다.
                        allSec = timerDateTime.seconds # 초 단위로 들고옵니다.
                        minute = int(allSec/60) # 분을 계산합니다.

                        sec = allSec - minute*60 # 분을 뺀 초를 계산합니다.
                        self.T1.display(minute) # UI에 분을 보여줍니다.
                        self.T2.display(sec) # UI에 초를 보여줍니다.
                        self.T3.display(int(timerDateTime.microseconds/10000)) # UI에 밀리초를 보여줍니다.

                    # 검출옵션이 켜져있다면
                    if self.bObjectDetection:
                        # ObjectClassifier로부터 추론결과물을 받습니다.
                        infer_time, classifiedLabel = self.objClassifier.getProcessedData()
                        if len(classifiedLabel) > 0 :
                            if classifiedLabel[0][1] >= self.CLASSIFICATION_CONF: # 가장 높은 수치의 신뢰도가 미리 지정해둔 값보다 크면
                                if self.prevFrameLabelIdx == -1 or self.prevFrameLabelIdx != classifiedLabel[0][0]: # 이전 프레임이 없거나 이전프레임에 검출된 사물레이블과 다르면
                                    self.prevFrameLabelIdx = classifiedLabel[0][0] # 이전프레임 레이블 인덱스를 업데이트합니다.
                                    self.sameDetectionFrameCount = 1 # 같은 사물이 검출된 횟수를 1로 설정합니다.
                                elif self.prevFrameLabelIdx == classifiedLabel[0][0]: # 이전프레임과 같은 사물이 검출되었다면
                                    self.sameDetectionFrameCount += 1 # 검출횟수를 1 증가시킵니다.
                            else: # 아무것도 검출이 되지않았다면
                                self.prevFrameLabelIdx = -1 # 이전프레임의 사물레이블 인덱스를 -1로 초기화합니다.
                                self.sameDetectionFrameCount = 0 # 검출횟수를 0으로 초기화합니다.

                            if self.sameDetectionFrameCount >= self.CLASSIFICATION_FRAME: # 같은사물이 연속해서 검출된 횟수가 미리 지정해둔 값보다 크면
                                detectedLabel = self.objClassifier.labelIdx2Name(classifiedLabel[0][0]) # 레이블 이름을 가져옵니다.
                                for i in range(len(self.picLabels)): # 캡쳐해야하는 레이블들에 대해
                                    if self.latestDetectedLabel != self.picLabels[i] and detectedLabel == self.picLabels[i]: # 마지막으로 캡쳐한 레이블이 아니면
                                        curTime = datetime.datetime.now() # 현재시간을 가져옵니다.
                                        millisecond = int(curTime.microsecond / 10000) # 밀리세컨드 단위로 변환합니다.
                                        self.Qt_picTimes[i][0].display(curTime.minute) # 분을 업데이트합니다.
                                        self.Qt_picTimes[i][1].display(curTime.second) # 초를 업데이트합니다.
                                        self.Qt_picTimes[i][2].display(millisecond) # 밀리초를 업데이트합니다.
                                        self.picDateTime[i] = curTime # 시간정보를 저장합니다.

                                        objRenderImg = cv2.resize(self.originFrame, (self.picRenderW, self.picRenderH)) # UI에 표시될 크기대로 resize합니다.
                                        objRenderImg = cv2.cvtColor(objRenderImg,cv2.COLOR_BGR2RGB) # 색상채널을 BGR에서 RGB로 변경합니다.
                                        ### QT GUI에 업데이트하는 과정입니다.
                                        bytesPerLine = 3 * self.picRenderW
                                        qImg = QtGui.QImage(objRenderImg.data, self.picRenderW, self.picRenderH,
                                                            bytesPerLine, QtGui.QImage.Format_RGB888)
                                        self.Qt_pics[i].setPixmap(QtGui.QPixmap(qImg))
                                        ###

                                        self.latestDetectedLabel = detectedLabel # 마지막으로 캡쳐된 사물레이블로 저장합니다.
                                        onlyObjFrameBGR = cv2.cvtColor(objRenderImg, cv2.COLOR_RGB2BGR) # 색상채널을 RGB에서 BGR로 변경합니다.
                                        cv2.imwrite('./captureResult/' + self.latestDetectedLabel + curTime.__str__()+ '.jpg', onlyObjFrameBGR) # 이미지를 저장합니다.
                                        self.log(self.latestDetectedLabel + ' captured')

                            # 추론된 최상위 3개 레이블의 conf값을 보여줍니다.
                            for i in range(3):
                                if i >= 3:
                                    break
                                if len(classifiedLabel) < 3:
                                    print(len(classifiedLabel))
                                labelIdx = classifiedLabel[i][0] # 사물의 레이블인덱스를 가져옵니다.
                                conf = classifiedLabel[i][1] # 추론 신뢰도를 가져옵니다.
                                labelStr = self.objClassifier.labelIdx2Name(labelIdx)
                                cv2.putText(renderImg, '%-15s' % labelStr + ' %.3f' % conf, (15, 60 + 45*i ),
                                cv2.FONT_HERSHEY_COMPLEX, 1.5, (10, 10, 200), 2) # 이미지에 적습니다.
                    if self.bObjectDetection: # 검출옵션이 켜져있다면
                        # frame에대한 정보 그리기
                        inf_time_message = "Inference time: {:.3f} ms".format(infer_time * 1000)
                        cv2.putText(renderImg, inf_time_message, (15, 15), cv2.FONT_HERSHEY_COMPLEX, 0.5,
                                    (200, 10, 10), 1)
                    # 표시할 이미지에 추론에 쓸 영역을 표시합니다.
                    cv2.rectangle(renderImg,(cut_rect[0],cut_rect[1]),(cut_rect[2],cut_rect[3]),(0,255,0),2)
                    renderImg = cv2.resize(renderImg, (renderingW, renderingH)) # UI에 표시될 크기대로 resize합니다.

                    ### QT GUI에 업데이트하는 과정입니다.
                    bytesPerLine = 3 * renderingW
                    qImg = QtGui.QImage(renderImg.data, renderingW, renderingH, bytesPerLine, QtGui.QImage.Format_RGB888)
                    self.videoimg.setPixmap(QtGui.QPixmap(qImg))
                    ###

        except Exception as error:
                traceback.print_exc()
                print("catch error")
    # 모든 캡쳐정보와 검출정보를 초기화하는 함수입니다.
    def resetDetectionInfo(self):
        for i in range(8): # 8개의 사물에 대해서
            self.Qt_pics[i].setPixmap(QtGui.QPixmap("./res/."+(i+1).__str__()+".jpg")) # UI에 띄워지는 이미지를 초기화합니다.
            # 검출시간을 0으로 초기화합니다.
            self.Qt_picTimes[i][0].display(0)
            self.Qt_picTimes[i][1].display(0)
            self.Qt_picTimes[i][2].display(0)
            # 검출정보를 초기화합니다.
            self.latestDetectedLabel=''
            self.picDateTime[i] = None
        # 타이머 시작시간을 초기화합니다.
        self.timerStartTime = None
        # 최종걸린시간을 0으로 초기화합니다.
        self.T1.display(0)
        self.T2.display(0)
        self.T3.display(0)
        # 캡쳐하여 저장했던 파일들을 삭제합니다. (linux전용입니다.)
        os.system('rm -f ./captureResult/*.jpg')


    # 스크립트 내용을 파일로 저장하는 함수입니다.
    def orderSave(self):
        filename = self.Qt_Filename.text() # 입력한 파일이름을 가져옵니다.
        if filename == '': # 공백이라면
            self.log('please input fileName')
            return # 함수를 종료합니다.
        f = open(filename,'w') # 파일을 만듭니다.
        f.write(self.Qt_ScriptList.toPlainText()) # 스크립트창의 내용을 씁니다.
        f.close() # 파일을 닫습니다.
        self.log(filename + ' file saved')
    # 스크립트 파일을 불러오는 함수입니다.
    def orderLoad(self):
        filename='./scripts/'+self.Qt_Filename.text() # 입력한 파일이름으로 경로를 구성합니다.
        try:
            self.log('openning ' + filename+ '...')
            f = open(filename, 'r') # 읽기모드로 엽니다.
            self.Qt_ScriptList.clear() # 스크립트창을 비웁니다.
            for str in f.readlines(): # 한줄씩 읽어서
                self.Qt_ScriptList.append(str.strip()) # 스크립트창에 추가합니다.
            f.close() # 파일을 닫습니다.
        except Exception as err:
            traceback.print_exc()
            self.log(err.__str__())
    # 스크립트를 시작하는 함수입니다.
    def orderStart(self):
        if self.bOrdering: # 이미 실행중이라면
            self.log('이미 실행중인 오더가 있습니다.')
            return # 함수를 종료합니다.
        self.bOrdering = True # 실행중으로 변경합니다.
        th = threading.Thread(target=self.orderThread) # 스크립트를 실행하는 쓰레드를 생성합니다.
        th.daemon = True # 메인쓰레드가 종료되면 종료되도록 설정합니다.
        th.start() # 쓰레드를 시작합니다.
    # 스크립트 실행중간에 일시정지하는 함수입니다.
    def orderPause(self):
        if self.bOrdering: # 스크립트가 실행중이면
            self.bOrderPause = True # 스크립트 일시정지상태로 변경합니다.
            self.pauseBtn.clicked.disconnect() # pause버튼에 할당된 함수를 연결해제합니다.
            self.pauseBtn.clicked.connect(self.orderResume) # pause버튼에 self.orderResume 함수를 연결합니다.
            self.pauseBtn.setText('Resume') # pause버튼의 text를 Resume으로 변경합니다.
            self.log('스크립트 일시정지.')
        else: # 스크립트가 실행중이지 않으면
            self.log('실행중인 스크립트가 없습니다.')
    # 스크립트가 일시정지인 상태에서 재개하는 함수입니다.
    def orderResume(self):
        self.bOrderPause = False # 일시정지하지않은 상태로 변경합니다.
        self.pauseBtn.clicked.disconnect() # pause버튼에 할당된 함수를 연결해제합니다.
        self.pauseBtn.clicked.connect(self.orderPause) # pause버튼에 self.orderPause 함수를 연결합니다.
        self.pauseBtn.setText('Pause') # pause버튼의 text를 Pause로 변경합니다.
        self.log('스크립트 계속진행.')
    # 진행중인 스크립트를 정지하는 함수입니다.
    def orderStop(self):
        self.bOrdering = False # 스크립트가 실행되지않은 상태로 변경합니다. 
        self.bOrderPause = False # 스크립트가 일시정지되지않은 상태로 변경합니다.
        self.pauseBtn.clicked.disconnect() # pause버튼에 할당된 함수를 연결해제합니다.
        self.pauseBtn.clicked.connect(self.orderPause) # pause버튼에 self.orderPause 함수를 연결합니다.
        self.pauseBtn.setText('Pause') # pause버튼의 text를 Pause로 변경합니다.
    # 스크립트를 진행하는 쓰레드의 시작지점입니다.
    def orderThread(self):
        cmds = self.Qt_ScriptList.toPlainText().split('\n') # 스크립트를 행단위로 나눕니다.
        cursor = self.Qt_ScriptList.textCursor() # 스크립트 창의 커서를 가져옵니다.
        for i, cmd in enumerate(cmds): # 명령어들에 대해서
            while self.bOrderPause: # 일시정지된 상태면 무한루프를 돕니다.
                if not self.bOrdering: # 스크립트가 정지되면 빠져나옵니다.
                    break
            if self.bOrdering: # 스크립트가 실행중이면
                cursor.movePosition(cursor.Left, cursor.KeepAnchor,  i+1) # 현재 실행할 명령어 줄의 위치로 커서를 옮깁니다.
                if not self.sendScriptCommand(cmd): # 명령어를 전송합니다. 전송에 실패하면
                    self.log('order재생중 오류')
                    break # for문을 빠져나갑니다.
        
        if not self.bOrdering: # 만약 정지버튼을 눌러서 정지된 경우
            self.log('order 중지')

        self.bOrdering = False # 실행중이 아닌 상태로 변경합니다.
        self.log('order가 종료되었습니다.')
    # 스크립트명령어를 해석하고 전송해주는 함수입니다.
    def sendScriptCommand(self, cmd):
        try:
            cmdSplitRes=cmd.split(' ') # 스크립트 명령어를 공백단위로 나눕니다.
            if cmdSplitRes[0] == 'sleep': # 만약 첫번째로 sleep이 나오면 
                sleepTime = float(cmdSplitRes[1]) # 뒤에나오는 문자를 flaot로 변환합니다.
                self.log('ORDER: '+ cmd)
                time.sleep(sleepTime) # 변환된 수만큼 코드실행을 멈춥니다.
                return True # 정상적으로 명령어를 실행했다고 반환합니다.
            else: # sleep 명령어가 아니면
                try:
                    self.tello.send_command(cmd) # 명령어 전체를 tello로 보냅니다.
                    self.log('ORDER: ' + cmd + ' to ' + self.tello.tello_address[0])
                except:
                    traceback.print_exc()
                    print('catch')
                    self.log('Order송신중 오류')
                    return False # 비정상적으로 명령어를 실행했다고 반환합니다.
                return True # 정상적으로 명령어를 실행했다고 반환합니다.
        except:
            traceback.print_exc()
            self.log('Order해석오류')
            return False # 비정상적으로 명령어를 실행했다고 반환합니다.

    # tello가 전송하는 이미지의 가로크기를 반환하는 함수입니다.
    def getCapW(self):
        if self.tello.cap is not None: # VideoCapture가 정상이라면
            return self.tello.cap.get(3) # 가로크기 값을 가져와 반환합니다.
        return -1 # 비정상이면 -1을 반환합니다.
    # tello가 전송하는 이미지의 세로크기를 반환하는 함수입니다.
    def getCapH(self):
        if self.tello.cap is not None: # VideoCapture가 정상이라면
            return self.tello.cap.get(4) # 세로크기 값을 가져와 반환합니다.
        return -1 # 비정상이면 -1을 반환합니다.
    # ObjectDetector에서 호출하는 함수입니다. Tello로부터 받은 이미지에서 일부를 잘라낸 이미지를 반환합니다.
    def getInferFrame(self):
        return self.inferFrame

    ### 이 아래 함수들은 UI와 변수들을 상호작용하게끔 하는 함수들입니다.
    # UI의 특정 이벤트에 함수를 바인딩합니다.
    def bindFuncs(self):
        # forward 버튼을 클릭했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.Forward_M1.clicked.connect(self.moveforward)
        self.Forward_M2.clicked.connect(self.moveforward)
        # backward 버튼을 클릭했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.Backward_M1.clicked.connect(self.movebackward)
        self.Backward_M2.clicked.connect(self.movebackward)
        # left 버튼을 클릭했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.Left_M1.clicked.connect(self.moveleft)
        self.Left_M2.clicked.connect(self.moveleft)
        # right 버튼을 클릭했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.Right_M1.clicked.connect(self.moveright)
        self.Right_M2.clicked.connect(self.moveright)
        # Up 버튼을 클릭했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.Up_M1.clicked.connect(self.Up)
        self.Up_M2.clicked.connect(self.Up)
        # Down 버튼을 클릭했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.Down_M1.clicked.connect(self.Down)
        self.Down_M2.clicked.connect(self.Down)
        # CW 버튼을 클릭했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.CW_M1.clicked.connect(self.rotateCW)
        self.CW_M2.clicked.connect(self.rotateCW)
        # CCW 버튼을 클릭했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.CCW_M1.clicked.connect(self.rotateCCW)
        self.CCW_M2.clicked.connect(self.rotateCCW)
        # takeoff 버튼을 클릭했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.TakeOff_M1.clicked.connect(self.takeoff)
        self.TakeOff_M2.clicked.connect(self.takeoff)
        # connect 버튼을 클릭했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.Connect_M1.clicked.connect(self.connect)
        self.Connect_M2.clicked.connect(self.connect)
        # land 버튼을 클릭했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.Land_M1.clicked.connect(self.land)
        self.Land_M2.clicked.connect(self.land)
        # snr check 버튼을 클릭했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.SNR_Check.clicked.connect(self.check)

        # spinbox
        # height 값을 조절했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.Height_Spinbox.valueChanged.connect(self.updateHeight)
        # rotate 값을 조절했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.Rotation_Spinbox.valueChanged.connect(self.updateRotation)
        # height와 rotate를 한번에 조절가능한 값을 조절했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.Master_Spinbox.valueChanged.connect(self.updateAll)
        # Left/Right 값을 조절했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.L_R_Spinbox.valueChanged.connect(self.updateLR)
        # Forward/Back 값을 조절했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.F_B_SpinBox.valueChanged.connect(self.updateFB)

        # 움직임 값을 조절하는 첫번째 방식을 선택했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.radioButton1.clicked.connect(self.enable)
        # 움직임 값을 조절하는 두번째 방식을 선택했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.radioButton3.clicked.connect(self.enable)
        # IP 텍스트입력창에 입력을 했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.IPAddress.textChanged.connect(self.updateIP)

        # 기록 초기화버튼을 클릭했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.TimerReset.clicked.connect(self.resetDetectionInfo)
        # 스크립트 저장버튼을 클릭했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.saveBtn.clicked.connect(self.orderSave)
        # 스크립트 불러오기버튼을 클릭했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.loadBtn.clicked.connect(self.orderLoad)
        # 스크립트 실행버튼을 클릭했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.startBtn.clicked.connect(self.orderStart)
        # 스크립트 정지버튼을 클릭했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.stopBtn.clicked.connect(self.orderStop)
        # 스크립트 일시정지버튼을 클릭했을 때 전달인자로 들어가는 함수가 호출되도록 설정합니다.
        self.pauseBtn.clicked.connect(self.orderPause)
    # 아래 함수코드는 QT designer에서 생성해준 코드입니다. UI를 생성하는 부분입니다.
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(1600, 965)
        Dialog.setMinimumSize(QtCore.QSize(1400, 965))
        Dialog.setMaximumSize(QtCore.QSize(1600, 965))
        self.verticalLayout_10 = QtWidgets.QVBoxLayout(Dialog)
        self.verticalLayout_10.setObjectName("verticalLayout_10")
        self.horizontalLayout_24 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_24.setObjectName("horizontalLayout_24")
        self.videoimg = QtWidgets.QLabel(Dialog)
        self.videoimg.setMinimumSize(QtCore.QSize(600, 450))
        self.videoimg.setMaximumSize(QtCore.QSize(600, 450))
        self.videoimg.setText("")
        self.videoimg.setPixmap(QtGui.QPixmap(":/Picture/sponsor.jpg"))
        self.videoimg.setObjectName("videoimg")
        self.horizontalLayout_24.addWidget(self.videoimg)
        self.gridLayout_7 = QtWidgets.QGridLayout()
        self.gridLayout_7.setObjectName("gridLayout_7")
        self.horizontalLayout_17 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_17.setObjectName("horizontalLayout_17")
        self.P4 = QtWidgets.QLabel(Dialog)
        self.P4.setText("")
        self.P4.setPixmap(QtGui.QPixmap(":/Picture/noimg.jpg"))
        self.P4.setObjectName("P4")
        self.horizontalLayout_17.addWidget(self.P4)
        self.P4_1 = QtWidgets.QLCDNumber(Dialog)
        self.P4_1.setDigitCount(2)
        self.P4_1.setProperty("intValue", 99)
        self.P4_1.setObjectName("P4_1")
        self.horizontalLayout_17.addWidget(self.P4_1)
        self.label_56 = QtWidgets.QLabel(Dialog)
        font = QtGui.QFont()
        font.setPointSize(25)
        self.label_56.setFont(font)
        self.label_56.setObjectName("label_56")
        self.horizontalLayout_17.addWidget(self.label_56)
        self.P4_2 = QtWidgets.QLCDNumber(Dialog)
        self.P4_2.setDigitCount(2)
        self.P4_2.setProperty("intValue", 99)
        self.P4_2.setObjectName("P4_2")
        self.horizontalLayout_17.addWidget(self.P4_2)
        self.label_57 = QtWidgets.QLabel(Dialog)
        font = QtGui.QFont()
        font.setPointSize(25)
        self.label_57.setFont(font)
        self.label_57.setObjectName("label_57")
        self.horizontalLayout_17.addWidget(self.label_57)
        self.P4_3 = QtWidgets.QLCDNumber(Dialog)
        self.P4_3.setDigitCount(2)
        self.P4_3.setProperty("intValue", 99)
        self.P4_3.setObjectName("P4_3")
        self.horizontalLayout_17.addWidget(self.P4_3)
        self.gridLayout_7.addLayout(self.horizontalLayout_17, 3, 0, 1, 1)
        self.horizontalLayout_25 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_25.setObjectName("horizontalLayout_25")
        self.P1 = QtWidgets.QLabel(Dialog)
        self.P1.setText("")
        self.P1.setPixmap(QtGui.QPixmap(":/Picture/noimg.jpg"))
        self.P1.setObjectName("P1")
        self.horizontalLayout_25.addWidget(self.P1)
        self.P1_1 = QtWidgets.QLCDNumber(Dialog)
        self.P1_1.setDigitCount(2)
        self.P1_1.setProperty("intValue", 99)
        self.P1_1.setObjectName("P1_1")
        self.horizontalLayout_25.addWidget(self.P1_1)
        self.label_68 = QtWidgets.QLabel(Dialog)
        font = QtGui.QFont()
        font.setPointSize(25)
        self.label_68.setFont(font)
        self.label_68.setObjectName("label_68")
        self.horizontalLayout_25.addWidget(self.label_68)
        self.P1_2 = QtWidgets.QLCDNumber(Dialog)
        self.P1_2.setDigitCount(2)
        self.P1_2.setProperty("intValue", 99)
        self.P1_2.setObjectName("P1_2")
        self.horizontalLayout_25.addWidget(self.P1_2)
        self.label_69 = QtWidgets.QLabel(Dialog)
        font = QtGui.QFont()
        font.setPointSize(25)
        self.label_69.setFont(font)
        self.label_69.setObjectName("label_69")
        self.horizontalLayout_25.addWidget(self.label_69)
        self.P1_3 = QtWidgets.QLCDNumber(Dialog)
        self.P1_3.setDigitCount(2)
        self.P1_3.setProperty("intValue", 99)
        self.P1_3.setObjectName("P1_3")
        self.horizontalLayout_25.addWidget(self.P1_3)
        self.gridLayout_7.addLayout(self.horizontalLayout_25, 0, 0, 1, 1)
        self.horizontalLayout_26 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_26.setObjectName("horizontalLayout_26")
        self.P5 = QtWidgets.QLabel(Dialog)
        self.P5.setText("")
        self.P5.setPixmap(QtGui.QPixmap(":/Picture/noimg.jpg"))
        self.P5.setObjectName("P5")
        self.horizontalLayout_26.addWidget(self.P5)
        self.P5_1 = QtWidgets.QLCDNumber(Dialog)
        self.P5_1.setDigitCount(2)
        self.P5_1.setProperty("intValue", 99)
        self.P5_1.setObjectName("P5_1")
        self.horizontalLayout_26.addWidget(self.P5_1)
        self.label_70 = QtWidgets.QLabel(Dialog)
        font = QtGui.QFont()
        font.setPointSize(25)
        self.label_70.setFont(font)
        self.label_70.setObjectName("label_70")
        self.horizontalLayout_26.addWidget(self.label_70)
        self.P5_2 = QtWidgets.QLCDNumber(Dialog)
        self.P5_2.setDigitCount(2)
        self.P5_2.setProperty("intValue", 99)
        self.P5_2.setObjectName("P5_2")
        self.horizontalLayout_26.addWidget(self.P5_2)
        self.label_71 = QtWidgets.QLabel(Dialog)
        font = QtGui.QFont()
        font.setPointSize(25)
        self.label_71.setFont(font)
        self.label_71.setObjectName("label_71")
        self.horizontalLayout_26.addWidget(self.label_71)
        self.P5_3 = QtWidgets.QLCDNumber(Dialog)
        self.P5_3.setDigitCount(2)
        self.P5_3.setProperty("intValue", 99)
        self.P5_3.setObjectName("P5_3")
        self.horizontalLayout_26.addWidget(self.P5_3)
        self.gridLayout_7.addLayout(self.horizontalLayout_26, 0, 1, 1, 1)
        self.horizontalLayout_4 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_4.setObjectName("horizontalLayout_4")
        self.P3 = QtWidgets.QLabel(Dialog)
        self.P3.setText("")
        self.P3.setPixmap(QtGui.QPixmap(":/Picture/noimg.jpg"))
        self.P3.setObjectName("P3")
        self.horizontalLayout_4.addWidget(self.P3)
        self.P3_1 = QtWidgets.QLCDNumber(Dialog)
        self.P3_1.setDigitCount(2)
        self.P3_1.setProperty("intValue", 99)
        self.P3_1.setObjectName("P3_1")
        self.horizontalLayout_4.addWidget(self.P3_1)
        self.label_49 = QtWidgets.QLabel(Dialog)
        font = QtGui.QFont()
        font.setPointSize(25)
        self.label_49.setFont(font)
        self.label_49.setObjectName("label_49")
        self.horizontalLayout_4.addWidget(self.label_49)
        self.P3_2 = QtWidgets.QLCDNumber(Dialog)
        self.P3_2.setDigitCount(2)
        self.P3_2.setProperty("intValue", 99)
        self.P3_2.setObjectName("P3_2")
        self.horizontalLayout_4.addWidget(self.P3_2)
        self.label_50 = QtWidgets.QLabel(Dialog)
        font = QtGui.QFont()
        font.setPointSize(25)
        self.label_50.setFont(font)
        self.label_50.setObjectName("label_50")
        self.horizontalLayout_4.addWidget(self.label_50)
        self.P3_3 = QtWidgets.QLCDNumber(Dialog)
        self.P3_3.setDigitCount(2)
        self.P3_3.setProperty("intValue", 99)
        self.P3_3.setObjectName("P3_3")
        self.horizontalLayout_4.addWidget(self.P3_3)
        self.gridLayout_7.addLayout(self.horizontalLayout_4, 2, 0, 1, 1)
        self.horizontalLayout_6 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_6.setObjectName("horizontalLayout_6")
        self.P7 = QtWidgets.QLabel(Dialog)
        self.P7.setText("")
        self.P7.setPixmap(QtGui.QPixmap(":/Picture/noimg.jpg"))
        self.P7.setObjectName("P7")
        self.horizontalLayout_6.addWidget(self.P7)
        self.P7_1 = QtWidgets.QLCDNumber(Dialog)
        self.P7_1.setDigitCount(2)
        self.P7_1.setProperty("intValue", 99)
        self.P7_1.setObjectName("P7_1")
        self.horizontalLayout_6.addWidget(self.P7_1)
        self.label_51 = QtWidgets.QLabel(Dialog)
        font = QtGui.QFont()
        font.setPointSize(25)
        self.label_51.setFont(font)
        self.label_51.setObjectName("label_51")
        self.horizontalLayout_6.addWidget(self.label_51)
        self.P7_2 = QtWidgets.QLCDNumber(Dialog)
        self.P7_2.setDigitCount(2)
        self.P7_2.setProperty("intValue", 99)
        self.P7_2.setObjectName("P7_2")
        self.horizontalLayout_6.addWidget(self.P7_2)
        self.label_52 = QtWidgets.QLabel(Dialog)
        font = QtGui.QFont()
        font.setPointSize(25)
        self.label_52.setFont(font)
        self.label_52.setObjectName("label_52")
        self.horizontalLayout_6.addWidget(self.label_52)
        self.P7_3 = QtWidgets.QLCDNumber(Dialog)
        self.P7_3.setDigitCount(2)
        self.P7_3.setProperty("intValue", 99)
        self.P7_3.setObjectName("P7_3")
        self.horizontalLayout_6.addWidget(self.P7_3)
        self.gridLayout_7.addLayout(self.horizontalLayout_6, 2, 1, 1, 1)
        self.horizontalLayout_5 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_5.setObjectName("horizontalLayout_5")
        self.P6 = QtWidgets.QLabel(Dialog)
        self.P6.setText("")
        self.P6.setPixmap(QtGui.QPixmap(":/Picture/noimg.jpg"))
        self.P6.setObjectName("P6")
        self.horizontalLayout_5.addWidget(self.P6)
        self.P6_1 = QtWidgets.QLCDNumber(Dialog)
        self.P6_1.setDigitCount(2)
        self.P6_1.setProperty("intValue", 99)
        self.P6_1.setObjectName("P6_12")
        self.horizontalLayout_5.addWidget(self.P6_1)
        self.label_8 = QtWidgets.QLabel(Dialog)
        font = QtGui.QFont()
        font.setPointSize(25)
        self.label_8.setFont(font)
        self.label_8.setObjectName("label_8")
        self.horizontalLayout_5.addWidget(self.label_8)
        self.P6_2 = QtWidgets.QLCDNumber(Dialog)
        self.P6_2.setDigitCount(2)
        self.P6_2.setProperty("intValue", 99)
        self.P6_2.setObjectName("P6_13")
        self.horizontalLayout_5.addWidget(self.P6_2)
        self.label_13 = QtWidgets.QLabel(Dialog)
        font = QtGui.QFont()
        font.setPointSize(25)
        self.label_13.setFont(font)
        self.label_13.setObjectName("label_13")
        self.horizontalLayout_5.addWidget(self.label_13)
        self.P6_3 = QtWidgets.QLCDNumber(Dialog)
        self.P6_3.setDigitCount(2)
        self.P6_3.setProperty("intValue", 99)
        self.P6_3.setObjectName("P6_3")
        self.horizontalLayout_5.addWidget(self.P6_3)
        self.gridLayout_7.addLayout(self.horizontalLayout_5, 1, 1, 1, 1)
        self.horizontalLayout_7 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_7.setObjectName("horizontalLayout_7")
        self.P8 = QtWidgets.QLabel(Dialog)
        self.P8.setText("")
        self.P8.setPixmap(QtGui.QPixmap(":/Picture/noimg.jpg"))
        self.P8.setObjectName("P8")
        self.horizontalLayout_7.addWidget(self.P8)
        self.P8_1 = QtWidgets.QLCDNumber(Dialog)
        self.P8_1.setDigitCount(2)
        self.P8_1.setProperty("intValue", 99)
        self.P8_1.setObjectName("P8_1")
        self.horizontalLayout_7.addWidget(self.P8_1)
        self.label_54 = QtWidgets.QLabel(Dialog)
        font = QtGui.QFont()
        font.setPointSize(25)
        self.label_54.setFont(font)
        self.label_54.setObjectName("label_54")
        self.horizontalLayout_7.addWidget(self.label_54)
        self.P8_2 = QtWidgets.QLCDNumber(Dialog)
        self.P8_2.setDigitCount(2)
        self.P8_2.setProperty("intValue", 99)
        self.P8_2.setObjectName("P8_2")
        self.horizontalLayout_7.addWidget(self.P8_2)
        self.label_55 = QtWidgets.QLabel(Dialog)
        font = QtGui.QFont()
        font.setPointSize(25)
        self.label_55.setFont(font)
        self.label_55.setObjectName("label_55")
        self.horizontalLayout_7.addWidget(self.label_55)
        self.P8_3 = QtWidgets.QLCDNumber(Dialog)
        self.P8_3.setDigitCount(2)
        self.P8_3.setProperty("intValue", 99)
        self.P8_3.setObjectName("P8_3")
        self.horizontalLayout_7.addWidget(self.P8_3)
        self.gridLayout_7.addLayout(self.horizontalLayout_7, 3, 1, 1, 1)
        self.horizontalLayout_3 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.P2 = QtWidgets.QLabel(Dialog)
        self.P2.setText("")
        self.P2.setPixmap(QtGui.QPixmap(":/Picture/noimg.jpg"))
        self.P2.setObjectName("P2")
        self.horizontalLayout_3.addWidget(self.P2)
        self.P2_1 = QtWidgets.QLCDNumber(Dialog)
        self.P2_1.setDigitCount(2)
        self.P2_1.setProperty("intValue", 99)
        self.P2_1.setObjectName("P2_1")
        self.horizontalLayout_3.addWidget(self.P2_1)
        self.label_7 = QtWidgets.QLabel(Dialog)
        font = QtGui.QFont()
        font.setPointSize(25)
        self.label_7.setFont(font)
        self.label_7.setObjectName("label_7")
        self.horizontalLayout_3.addWidget(self.label_7)
        self.P2_2 = QtWidgets.QLCDNumber(Dialog)
        self.P2_2.setDigitCount(2)
        self.P2_2.setProperty("intValue", 99)
        self.P2_2.setObjectName("P2_2")
        self.horizontalLayout_3.addWidget(self.P2_2)
        self.label_12 = QtWidgets.QLabel(Dialog)
        font = QtGui.QFont()
        font.setPointSize(25)
        self.label_12.setFont(font)
        self.label_12.setObjectName("label_12")
        self.horizontalLayout_3.addWidget(self.label_12)
        self.P2_3 = QtWidgets.QLCDNumber(Dialog)
        self.P2_3.setDigitCount(2)
        self.P2_3.setProperty("intValue", 99)
        self.P2_3.setObjectName("P2_3")
        self.horizontalLayout_3.addWidget(self.P2_3)
        self.gridLayout_7.addLayout(self.horizontalLayout_3, 1, 0, 1, 1)
        self.horizontalLayout_24.addLayout(self.gridLayout_7)
        self.verticalLayout_10.addLayout(self.horizontalLayout_24)
        self.horizontalLayout_29 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_29.setObjectName("horizontalLayout_29")
        self.verticalLayout_9 = QtWidgets.QVBoxLayout()
        self.verticalLayout_9.setObjectName("verticalLayout_9")
        self.verticalLayout_3 = QtWidgets.QVBoxLayout()
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.TimerReset = QtWidgets.QPushButton(Dialog)
        font = QtGui.QFont()
        font.setPointSize(25)
        self.TimerReset.setFont(font)
        self.TimerReset.setObjectName("TimerReset")
        self.verticalLayout_3.addWidget(self.TimerReset)
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.label_53 = QtWidgets.QLabel(Dialog)
        self.label_53.setText("")
        self.label_53.setPixmap(QtGui.QPixmap(":/Picture/time.jpg"))
        self.label_53.setObjectName("label_53")
        self.horizontalLayout_2.addWidget(self.label_53)
        self.T1 = QtWidgets.QLCDNumber(Dialog)
        self.T1.setDigitCount(2)
        self.T1.setProperty("intValue", 99)
        self.T1.setObjectName("T1")
        self.horizontalLayout_2.addWidget(self.T1)
        self.label = QtWidgets.QLabel(Dialog)
        font = QtGui.QFont()
        font.setPointSize(25)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.horizontalLayout_2.addWidget(self.label)
        self.T2 = QtWidgets.QLCDNumber(Dialog)
        self.T2.setDigitCount(2)
        self.T2.setProperty("intValue", 99)
        self.T2.setObjectName("T2")
        self.horizontalLayout_2.addWidget(self.T2)
        self.label_2 = QtWidgets.QLabel(Dialog)
        font = QtGui.QFont()
        font.setPointSize(25)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.horizontalLayout_2.addWidget(self.label_2)
        self.T3 = QtWidgets.QLCDNumber(Dialog)
        self.T3.setDigitCount(2)
        self.T3.setProperty("intValue", 99)
        self.T3.setObjectName("T3")
        self.horizontalLayout_2.addWidget(self.T3)
        self.verticalLayout_3.addLayout(self.horizontalLayout_2)
        self.verticalLayout_9.addLayout(self.verticalLayout_3)
        self.horizontalLayout_28 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_28.setObjectName("horizontalLayout_28")
        self.loglist = QtWidgets.QTextEdit(Dialog)
        self.loglist.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOn)
        self.loglist.setObjectName("loglist")
        self.horizontalLayout_28.addWidget(self.loglist)
        self.verticalLayout_8 = QtWidgets.QVBoxLayout()
        self.verticalLayout_8.setObjectName("verticalLayout_8")
        self.Qt_ScriptList = QtWidgets.QTextEdit(Dialog)
        self.Qt_ScriptList.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOn)
        self.Qt_ScriptList.setObjectName("Qt_ScriptList")
        self.verticalLayout_8.addWidget(self.Qt_ScriptList)
        self.horizontalLayout_27 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_27.setObjectName("horizontalLayout_27")
        self.startBtn = QtWidgets.QPushButton(Dialog)
        self.startBtn.setObjectName("pushButton_2")
        self.horizontalLayout_27.addWidget(self.startBtn)
        self.pauseBtn = QtWidgets.QPushButton(Dialog)
        self.pauseBtn.setObjectName("pushButton_4")
        self.horizontalLayout_27.addWidget(self.pauseBtn)
        self.stopBtn = QtWidgets.QPushButton(Dialog)
        self.stopBtn.setObjectName("pushButton_3")
        self.horizontalLayout_27.addWidget(self.stopBtn)
        self.verticalLayout_8.addLayout(self.horizontalLayout_27)
        self.horizontalLayout_18 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_18.setObjectName("horizontalLayout_18")
        # self.scriptline = QtWidgets.QLineEdit(Dialog)
        # self.scriptline.setObjectName("scriptline")
        # self.horizontalLayout_18.addWidget(self.scriptline)
        # self.remove = QtWidgets.QPushButton(Dialog)
        # self.remove.setObjectName("remove")
        # self.horizontalLayout_18.addWidget(self.remove)
        self.verticalLayout_8.addLayout(self.horizontalLayout_18)
        self.horizontalLayout_19 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_19.setObjectName("horizontalLayout_19")
        self.Qt_Filename = QtWidgets.QLineEdit(Dialog)
        self.Qt_Filename.setObjectName("lineEdit")
        self.horizontalLayout_19.addWidget(self.Qt_Filename)
        self.saveBtn = QtWidgets.QPushButton(Dialog)
        self.saveBtn.setObjectName("save")
        self.horizontalLayout_19.addWidget(self.saveBtn)
        self.loadBtn = QtWidgets.QPushButton(Dialog)
        self.loadBtn.setObjectName("pushButton")
        self.horizontalLayout_19.addWidget(self.loadBtn)
        self.verticalLayout_8.addLayout(self.horizontalLayout_19)
        self.horizontalLayout_28.addLayout(self.verticalLayout_8)
        self.verticalLayout_9.addLayout(self.horizontalLayout_28)
        self.horizontalLayout_29.addLayout(self.verticalLayout_9)
        self.verticalLayout_4 = QtWidgets.QVBoxLayout()
        self.verticalLayout_4.setObjectName("verticalLayout_4")
        self.table = QtWidgets.QTabWidget(Dialog)
        self.table.setObjectName("table")
        self.droneinfo = QtWidgets.QWidget()
        self.droneinfo.setObjectName("droneinfo")
        self.verticalLayout_6 = QtWidgets.QVBoxLayout(self.droneinfo)
        self.verticalLayout_6.setObjectName("verticalLayout_6")
        self.horizontalLayout_10 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_10.setObjectName("horizontalLayout_10")
        self.label_5 = QtWidgets.QLabel(self.droneinfo)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.label_5.setFont(font)
        self.label_5.setObjectName("label_5")
        self.horizontalLayout_10.addWidget(self.label_5)
        self.Battery = QtWidgets.QProgressBar(self.droneinfo)
        self.Battery.setProperty("value", 100)
        self.Battery.setObjectName("Battery")
        self.horizontalLayout_10.addWidget(self.Battery)
        self.verticalLayout_6.addLayout(self.horizontalLayout_10)
        self.horizontalLayout_11 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_11.setObjectName("horizontalLayout_11")
        self.label_6 = QtWidgets.QLabel(self.droneinfo)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.label_6.setFont(font)
        self.label_6.setObjectName("label_6")
        self.horizontalLayout_11.addWidget(self.label_6)
        self.wifi_snr = QtWidgets.QProgressBar(self.droneinfo)
        self.wifi_snr.setProperty("value", 99)
        self.wifi_snr.setObjectName("wifi_snr")
        self.horizontalLayout_11.addWidget(self.wifi_snr)
        self.SNR_Check = QtWidgets.QPushButton(self.droneinfo)
        self.SNR_Check.setObjectName("SNR_Check")
        self.horizontalLayout_11.addWidget(self.SNR_Check)
        self.verticalLayout_6.addLayout(self.horizontalLayout_11)
        self.horizontalLayout_12 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_12.setObjectName("horizontalLayout_12")
        self.Height = QtWidgets.QLabel(self.droneinfo)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.Height.setFont(font)
        self.Height.setObjectName("Height")
        self.horizontalLayout_12.addWidget(self.Height)
        self.TOF = QtWidgets.QLabel(self.droneinfo)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.TOF.setFont(font)
        self.TOF.setAcceptDrops(False)
        self.TOF.setObjectName("TOF")
        self.horizontalLayout_12.addWidget(self.TOF)
        self.verticalLayout_6.addLayout(self.horizontalLayout_12)
        self.F_Time = QtWidgets.QLabel(self.droneinfo)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.F_Time.setFont(font)
        self.F_Time.setObjectName("F_Time")
        self.verticalLayout_6.addWidget(self.F_Time)
        self.verticalLayout_5 = QtWidgets.QVBoxLayout()
        self.verticalLayout_5.setObjectName("verticalLayout_5")
        self.label_9 = QtWidgets.QLabel(self.droneinfo)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.label_9.setFont(font)
        self.label_9.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignVCenter)
        self.label_9.setObjectName("label_9")
        self.verticalLayout_5.addWidget(self.label_9)
        self.temp = QtWidgets.QLabel(self.droneinfo)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.temp.setFont(font)
        self.temp.setObjectName("temp")
        self.verticalLayout_5.addWidget(self.temp)
        self.verticalLayout_6.addLayout(self.verticalLayout_5)
        self.table.addTab(self.droneinfo, "")
        self.setting = QtWidgets.QWidget()
        self.setting.setObjectName("setting")
        self.verticalLayout_7 = QtWidgets.QVBoxLayout(self.setting)
        self.verticalLayout_7.setObjectName("verticalLayout_7")
        self.horizontalLayout_16 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_16.setObjectName("horizontalLayout_16")
        self.label_11 = QtWidgets.QLabel(self.setting)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.label_11.setFont(font)
        self.label_11.setAlignment(QtCore.Qt.AlignCenter)
        self.label_11.setObjectName("label_11")
        self.horizontalLayout_16.addWidget(self.label_11)
        self.IPAddress = QtWidgets.QLineEdit(self.setting)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.IPAddress.setFont(font)
        self.IPAddress.setAlignment(QtCore.Qt.AlignCenter)
        self.IPAddress.setObjectName("IPAddress")
        self.horizontalLayout_16.addWidget(self.IPAddress)
        spacerItem = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_16.addItem(spacerItem)
        self.verticalLayout_7.addLayout(self.horizontalLayout_16)
        self.horizontalLayout_15 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_15.setObjectName("horizontalLayout_15")
        self.horizontalLayout_14 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_14.setObjectName("horizontalLayout_14")
        self.label_27 = QtWidgets.QLabel(self.setting)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.label_27.setFont(font)
        self.label_27.setObjectName("label_27")
        self.horizontalLayout_14.addWidget(self.label_27)
        self.Height_Spinbox = QtWidgets.QSpinBox(self.setting)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.Height_Spinbox.setFont(font)
        self.Height_Spinbox.setMinimum(20)
        self.Height_Spinbox.setMaximum(999)
        self.Height_Spinbox.setObjectName("Height_Spinbox")
        self.horizontalLayout_14.addWidget(self.Height_Spinbox)
        self.label_28 = QtWidgets.QLabel(self.setting)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.label_28.setFont(font)
        self.label_28.setObjectName("label_28")
        self.horizontalLayout_14.addWidget(self.label_28)
        self.horizontalLayout_15.addLayout(self.horizontalLayout_14)
        self.horizontalLayout_13 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_13.setObjectName("horizontalLayout_13")
        self.label_31 = QtWidgets.QLabel(self.setting)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.label_31.setFont(font)
        self.label_31.setObjectName("label_31")
        self.horizontalLayout_13.addWidget(self.label_31)
        self.Rotation_Spinbox = QtWidgets.QSpinBox(self.setting)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.Rotation_Spinbox.setFont(font)
        self.Rotation_Spinbox.setMinimum(1)
        self.Rotation_Spinbox.setMaximum(360)
        self.Rotation_Spinbox.setProperty("value", 45)
        self.Rotation_Spinbox.setObjectName("Rotation_Spinbox")
        self.horizontalLayout_13.addWidget(self.Rotation_Spinbox)
        self.label_32 = QtWidgets.QLabel(self.setting)
        self.label_32.setObjectName("label_32")
        self.horizontalLayout_13.addWidget(self.label_32)
        spacerItem1 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_13.addItem(spacerItem1)
        self.horizontalLayout_15.addLayout(self.horizontalLayout_13)
        self.verticalLayout_7.addLayout(self.horizontalLayout_15)
        self.horizontalLayout_33 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_33.setObjectName("horizontalLayout_33")
        self.radioButton1 = QtWidgets.QRadioButton(self.setting)
        self.radioButton1.setText("")
        self.radioButton1.setChecked(True)
        self.radioButton1.setObjectName("radioButton1")
        self.horizontalLayout_33.addWidget(self.radioButton1)
        self.horizontalLayout_34 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_34.setObjectName("horizontalLayout_34")
        self.label_35 = QtWidgets.QLabel(self.setting)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.label_35.setFont(font)
        self.label_35.setObjectName("label_35")
        self.horizontalLayout_34.addWidget(self.label_35)
        self.Master_Spinbox = QtWidgets.QSpinBox(self.setting)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.Master_Spinbox.setFont(font)
        self.Master_Spinbox.setMinimum(20)
        self.Master_Spinbox.setMaximum(500)
        self.Master_Spinbox.setProperty("value", 20)
        self.Master_Spinbox.setObjectName("Master_Spinbox")
        self.horizontalLayout_34.addWidget(self.Master_Spinbox)
        self.label_36 = QtWidgets.QLabel(self.setting)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.label_36.setFont(font)
        self.label_36.setObjectName("label_36")
        self.horizontalLayout_34.addWidget(self.label_36)
        spacerItem2 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout_34.addItem(spacerItem2)
        self.horizontalLayout_33.addLayout(self.horizontalLayout_34)
        self.verticalLayout_7.addLayout(self.horizontalLayout_33)
        self.horizontalLayout_9 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_9.setObjectName("horizontalLayout_9")
        self.radioButton3 = QtWidgets.QRadioButton(self.setting)
        self.radioButton3.setText("")
        self.radioButton3.setObjectName("radioButton3")
        self.horizontalLayout_9.addWidget(self.radioButton3)
        self.horizontalLayout_8 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_8.setObjectName("horizontalLayout_8")
        self.horizontalLayout_41 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_41.setObjectName("horizontalLayout_41")
        self.label_41 = QtWidgets.QLabel(self.setting)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.label_41.setFont(font)
        self.label_41.setObjectName("label_41")
        self.horizontalLayout_41.addWidget(self.label_41)
        self.F_B_SpinBox = QtWidgets.QSpinBox(self.setting)
        self.F_B_SpinBox.setEnabled(False)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.F_B_SpinBox.setFont(font)
        self.F_B_SpinBox.setMinimum(20)
        self.F_B_SpinBox.setMaximum(500)
        self.F_B_SpinBox.setProperty("value", 20)
        self.F_B_SpinBox.setObjectName("F_B_SpinBox")
        self.horizontalLayout_41.addWidget(self.F_B_SpinBox)
        self.label_42 = QtWidgets.QLabel(self.setting)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.label_42.setFont(font)
        self.label_42.setObjectName("label_42")
        self.horizontalLayout_41.addWidget(self.label_42)
        self.horizontalLayout_8.addLayout(self.horizontalLayout_41)
        self.horizontalLayout = QtWidgets.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label_43 = QtWidgets.QLabel(self.setting)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.label_43.setFont(font)
        self.label_43.setObjectName("label_43")
        self.horizontalLayout.addWidget(self.label_43)
        self.L_R_Spinbox = QtWidgets.QSpinBox(self.setting)
        self.L_R_Spinbox.setEnabled(False)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.L_R_Spinbox.setFont(font)
        self.L_R_Spinbox.setMinimum(20)
        self.L_R_Spinbox.setMaximum(500)
        self.L_R_Spinbox.setProperty("value", 20)
        self.L_R_Spinbox.setObjectName("L_R_Spinbox")
        self.horizontalLayout.addWidget(self.L_R_Spinbox)
        self.label_44 = QtWidgets.QLabel(self.setting)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.label_44.setFont(font)
        self.label_44.setObjectName("label_44")
        self.horizontalLayout.addWidget(self.label_44)
        spacerItem3 = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem3)
        self.horizontalLayout_8.addLayout(self.horizontalLayout)
        self.horizontalLayout_9.addLayout(self.horizontalLayout_8)
        self.verticalLayout_7.addLayout(self.horizontalLayout_9)
        self.table.addTab(self.setting, "")
        self.verticalLayout_4.addWidget(self.table)
        self.contorlWidget = QtWidgets.QTabWidget(Dialog)
        self.contorlWidget.setObjectName("contorlWidget")
        self.mode1 = QtWidgets.QWidget()
        self.mode1.setObjectName("mode1")
        self.gridLayout_6 = QtWidgets.QGridLayout(self.mode1)
        self.gridLayout_6.setObjectName("gridLayout_6")
        self.gridLayout_5 = QtWidgets.QGridLayout()
        self.gridLayout_5.setObjectName("gridLayout_5")
        self.Forward_M1 = QtWidgets.QPushButton(self.mode1)
        self.Forward_M1.setEnabled(False)
        self.Forward_M1.setMinimumSize(QtCore.QSize(60, 60))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.Forward_M1.setFont(font)
        self.Forward_M1.setObjectName("Forward_M1")
        self.gridLayout_5.addWidget(self.Forward_M1, 0, 1, 1, 1)
        self.Left_M1 = QtWidgets.QPushButton(self.mode1)
        self.Left_M1.setEnabled(False)
        self.Left_M1.setMinimumSize(QtCore.QSize(60, 60))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.Left_M1.setFont(font)
        self.Left_M1.setObjectName("Left_M1")
        self.gridLayout_5.addWidget(self.Left_M1, 1, 0, 1, 1)
        self.Right_M1 = QtWidgets.QPushButton(self.mode1)
        self.Right_M1.setEnabled(False)
        self.Right_M1.setMinimumSize(QtCore.QSize(60, 60))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.Right_M1.setFont(font)
        self.Right_M1.setObjectName("Right_M1")
        self.gridLayout_5.addWidget(self.Right_M1, 1, 2, 1, 1)
        self.Backward_M1 = QtWidgets.QPushButton(self.mode1)
        self.Backward_M1.setEnabled(False)
        self.Backward_M1.setMinimumSize(QtCore.QSize(60, 60))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.Backward_M1.setFont(font)
        self.Backward_M1.setObjectName("Backward_M1")
        self.gridLayout_5.addWidget(self.Backward_M1, 2, 1, 1, 1)
        self.gridLayout_6.addLayout(self.gridLayout_5, 0, 2, 1, 1)
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.TakeOff_M1 = QtWidgets.QPushButton(self.mode1)
        self.TakeOff_M1.setEnabled(False)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.TakeOff_M1.setFont(font)
        self.TakeOff_M1.setObjectName("TakeOff_M1")
        self.verticalLayout_2.addWidget(self.TakeOff_M1)
        self.Connect_M1 = QtWidgets.QPushButton(self.mode1)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.Connect_M1.setFont(font)
        self.Connect_M1.setObjectName("Connect_M1")
        self.verticalLayout_2.addWidget(self.Connect_M1)
        self.Land_M1 = QtWidgets.QPushButton(self.mode1)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.Land_M1.setFont(font)
        self.Land_M1.setObjectName("Land_M1")
        self.verticalLayout_2.addWidget(self.Land_M1)
        self.gridLayout_6.addLayout(self.verticalLayout_2, 0, 1, 1, 1)
        self.gridLayout_4 = QtWidgets.QGridLayout()
        self.gridLayout_4.setObjectName("gridLayout_4")
        self.Up_M1 = QtWidgets.QPushButton(self.mode1)
        self.Up_M1.setEnabled(False)
        self.Up_M1.setMinimumSize(QtCore.QSize(60, 60))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.Up_M1.setFont(font)
        self.Up_M1.setObjectName("Up_M1")
        self.gridLayout_4.addWidget(self.Up_M1, 0, 1, 1, 1)
        self.CCW_M1 = QtWidgets.QPushButton(self.mode1)
        self.CCW_M1.setEnabled(False)
        self.CCW_M1.setMinimumSize(QtCore.QSize(60, 60))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.CCW_M1.setFont(font)
        self.CCW_M1.setObjectName("CCW_M1")
        self.gridLayout_4.addWidget(self.CCW_M1, 1, 0, 1, 1)
        self.CW_M1 = QtWidgets.QPushButton(self.mode1)
        self.CW_M1.setEnabled(False)
        self.CW_M1.setMinimumSize(QtCore.QSize(60, 60))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.CW_M1.setFont(font)
        self.CW_M1.setObjectName("CW_M1")
        self.gridLayout_4.addWidget(self.CW_M1, 1, 2, 1, 1)
        self.Down_M1 = QtWidgets.QPushButton(self.mode1)
        self.Down_M1.setEnabled(False)
        self.Down_M1.setMinimumSize(QtCore.QSize(60, 60))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.Down_M1.setFont(font)
        self.Down_M1.setObjectName("Down_M1")
        self.gridLayout_4.addWidget(self.Down_M1, 2, 1, 1, 1)
        self.gridLayout_6.addLayout(self.gridLayout_4, 0, 0, 1, 1)
        self.contorlWidget.addTab(self.mode1, "")
        self.tab2 = QtWidgets.QWidget()
        self.tab2.setObjectName("tab2")
        self.gridLayout_3 = QtWidgets.QGridLayout(self.tab2)
        self.gridLayout_3.setObjectName("gridLayout_3")
        self.gridLayout = QtWidgets.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")
        self.Forward_M2 = QtWidgets.QPushButton(self.tab2)
        self.Forward_M2.setEnabled(False)
        self.Forward_M2.setMinimumSize(QtCore.QSize(60, 60))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.Forward_M2.setFont(font)
        self.Forward_M2.setObjectName("Forward_M2")
        self.gridLayout.addWidget(self.Forward_M2, 0, 1, 1, 1)
        self.CCW_M2 = QtWidgets.QPushButton(self.tab2)
        self.CCW_M2.setEnabled(False)
        self.CCW_M2.setMinimumSize(QtCore.QSize(60, 60))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.CCW_M2.setFont(font)
        self.CCW_M2.setObjectName("CCW_M2")
        self.gridLayout.addWidget(self.CCW_M2, 1, 0, 1, 1)
        self.CW_M2 = QtWidgets.QPushButton(self.tab2)
        self.CW_M2.setEnabled(False)
        self.CW_M2.setMinimumSize(QtCore.QSize(60, 60))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.CW_M2.setFont(font)
        self.CW_M2.setObjectName("CW_M2")
        self.gridLayout.addWidget(self.CW_M2, 1, 2, 1, 1)
        self.Backward_M2 = QtWidgets.QPushButton(self.tab2)
        self.Backward_M2.setEnabled(False)
        self.Backward_M2.setMinimumSize(QtCore.QSize(60, 60))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.Backward_M2.setFont(font)
        self.Backward_M2.setObjectName("Backward_M2")
        self.gridLayout.addWidget(self.Backward_M2, 2, 1, 1, 1)
        self.gridLayout_3.addLayout(self.gridLayout, 0, 0, 1, 1)
        self.verticalLayout = QtWidgets.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.TakeOff_M2 = QtWidgets.QPushButton(self.tab2)
        self.TakeOff_M2.setEnabled(False)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.TakeOff_M2.setFont(font)
        self.TakeOff_M2.setObjectName("TakeOff_M2")
        self.verticalLayout.addWidget(self.TakeOff_M2)
        self.Connect_M2 = QtWidgets.QPushButton(self.tab2)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.Connect_M2.setFont(font)
        self.Connect_M2.setObjectName("Connect_M2")
        self.verticalLayout.addWidget(self.Connect_M2)
        self.Land_M2 = QtWidgets.QPushButton(self.tab2)
        font = QtGui.QFont()
        font.setPointSize(15)
        self.Land_M2.setFont(font)
        self.Land_M2.setObjectName("Land_M2")
        self.verticalLayout.addWidget(self.Land_M2)
        self.gridLayout_3.addLayout(self.verticalLayout, 0, 1, 1, 1)
        self.gridLayout_2 = QtWidgets.QGridLayout()
        self.gridLayout_2.setObjectName("gridLayout_2")
        self.Left_M2 = QtWidgets.QPushButton(self.tab2)
        self.Left_M2.setEnabled(False)
        self.Left_M2.setMinimumSize(QtCore.QSize(60, 60))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.Left_M2.setFont(font)
        self.Left_M2.setObjectName("Left_M2")
        self.gridLayout_2.addWidget(self.Left_M2, 1, 0, 1, 1)
        self.Right_M2 = QtWidgets.QPushButton(self.tab2)
        self.Right_M2.setEnabled(False)
        self.Right_M2.setMinimumSize(QtCore.QSize(60, 60))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.Right_M2.setFont(font)
        self.Right_M2.setObjectName("Right_M2")
        self.gridLayout_2.addWidget(self.Right_M2, 1, 2, 1, 1)
        self.Up_M2 = QtWidgets.QPushButton(self.tab2)
        self.Up_M2.setEnabled(False)
        self.Up_M2.setMinimumSize(QtCore.QSize(60, 60))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.Up_M2.setFont(font)
        self.Up_M2.setObjectName("Up_M2")
        self.gridLayout_2.addWidget(self.Up_M2, 0, 1, 1, 1)
        self.Down_M2 = QtWidgets.QPushButton(self.tab2)
        self.Down_M2.setEnabled(False)
        self.Down_M2.setMinimumSize(QtCore.QSize(60, 60))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.Down_M2.setFont(font)
        self.Down_M2.setObjectName("Down_M2")
        self.gridLayout_2.addWidget(self.Down_M2, 2, 1, 1, 1)
        self.gridLayout_3.addLayout(self.gridLayout_2, 0, 2, 1, 1)
        self.contorlWidget.addTab(self.tab2, "")
        self.verticalLayout_4.addWidget(self.contorlWidget)
        self.horizontalLayout_29.addLayout(self.verticalLayout_4)
        self.verticalLayout_10.addLayout(self.horizontalLayout_29)

        self.retranslateUi(Dialog)
        self.table.setCurrentIndex(0)
        self.contorlWidget.setCurrentIndex(1)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
    # 아래 함수코드는 QT designer에서 생성해준 코드입니다. UI들의 초기세팅을 하는 부분입니다.
    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Tello_Gui_U_ver"))
        self.label_56.setText(_translate("Dialog", "분"))
        self.label_57.setText(_translate("Dialog", "초"))
        self.label_68.setText(_translate("Dialog", "분"))
        self.label_69.setText(_translate("Dialog", "초"))
        self.label_70.setText(_translate("Dialog", "분"))
        self.label_71.setText(_translate("Dialog", "초"))
        self.label_49.setText(_translate("Dialog", "분"))
        self.label_50.setText(_translate("Dialog", "초"))
        self.label_51.setText(_translate("Dialog", "분"))
        self.label_52.setText(_translate("Dialog", "초"))
        self.label_8.setText(_translate("Dialog", "분"))
        self.label_13.setText(_translate("Dialog", "초"))
        self.label_54.setText(_translate("Dialog", "분"))
        self.label_55.setText(_translate("Dialog", "초"))
        self.label_7.setText(_translate("Dialog", "분"))
        self.label_12.setText(_translate("Dialog", "초"))
        self.TimerReset.setText(_translate("Dialog", "RESET"))
        self.label.setText(_translate("Dialog", "분"))
        self.label_2.setText(_translate("Dialog", "초"))
        self.startBtn.setText(_translate("Dialog", "START"))
        self.pauseBtn.setText(_translate("Dialog", "PAUSE"))
        self.stopBtn.setText(_translate("Dialog", "STOP"))
        #self.remove.setText(_translate("Dialog", "Remove"))
        self.saveBtn.setText(_translate("Dialog", "Save"))
        self.loadBtn.setText(_translate("Dialog", "Load"))
        self.label_5.setText(_translate("Dialog", "BATTERY"))
        self.label_6.setText(_translate("Dialog", "Wi-Fi SNR"))
        self.SNR_Check.setText(_translate("Dialog", "Check"))
        self.Height.setText(_translate("Dialog", "Height: 1234cm"))
        self.TOF.setText(_translate("Dialog", "TOF: 1234cm"))
        self.F_Time.setText(_translate("Dialog", "Flight Time: 00:00:00"))
        self.label_9.setText(_translate("Dialog", "Temperature"))
        self.temp.setText(_translate("Dialog", "Min: 00ºC Max: 00ºC"))
        self.table.setTabText(self.table.indexOf(self.droneinfo), _translate("Dialog", "Drone info"))
        self.label_11.setText(_translate("Dialog", "My IP  Address"))
        self.IPAddress.setText(_translate("Dialog", "192.168.10.2"))
        self.label_27.setText(_translate("Dialog", "Height(Up,Down)"))
        self.label_28.setText(_translate("Dialog", "CM"))
        self.label_31.setText(_translate("Dialog", "CCW,CW"))
        self.label_32.setText(_translate("Dialog", "º"))
        self.label_35.setText(_translate("Dialog", "Move(↑,↓,←, →,)"))
        self.label_36.setText(_translate("Dialog", "CM"))
        self.label_41.setText(_translate("Dialog", "Forward,Back(↑,↓)"))
        self.label_42.setText(_translate("Dialog", "CM"))
        self.label_43.setText(_translate("Dialog", "Left,Right(←, →) "))
        self.label_44.setText(_translate("Dialog", "CM"))
        self.table.setTabText(self.table.indexOf(self.setting), _translate("Dialog", "Setting"))
        self.Forward_M1.setText(_translate("Dialog", "↑"))
        self.Left_M1.setText(_translate("Dialog", "← "))
        self.Right_M1.setText(_translate("Dialog", "→ "))
        self.Backward_M1.setText(_translate("Dialog", "↓"))
        self.TakeOff_M1.setText(_translate("Dialog", "Take Off"))
        self.Connect_M1.setText(_translate("Dialog", "Connect"))
        self.Land_M1.setText(_translate("Dialog", "Land"))
        self.Up_M1.setText(_translate("Dialog", "Up"))
        self.CCW_M1.setText(_translate("Dialog", "CCW"))
        self.CW_M1.setText(_translate("Dialog", "CW"))
        self.Down_M1.setText(_translate("Dialog", "Down"))
        self.contorlWidget.setTabText(self.contorlWidget.indexOf(self.mode1), _translate("Dialog", "Mode1"))
        self.Forward_M2.setText(_translate("Dialog", "↑"))
        self.CCW_M2.setText(_translate("Dialog", "CCW"))
        self.CW_M2.setText(_translate("Dialog", "CW"))
        self.Backward_M2.setText(_translate("Dialog", "↓"))
        self.TakeOff_M2.setText(_translate("Dialog", "Take Off"))
        self.Connect_M2.setText(_translate("Dialog", "Connect"))
        self.Land_M2.setText(_translate("Dialog", "Land"))
        self.Left_M2.setText(_translate("Dialog", "← "))
        self.Right_M2.setText(_translate("Dialog", "→ "))
        self.Up_M2.setText(_translate("Dialog", "Up"))
        self.Down_M2.setText(_translate("Dialog", "Down"))
        self.contorlWidget.setTabText(self.contorlWidget.indexOf(self.tab2), _translate("Dialog", "Mode2"))
        self.tempTextFormat = "Min: %02dºC Max: %02dºC"
        self.HeightTextFormat = "Height: %4dcm"
        self.TOF_TextFormat = "TOF: %4dcm"
        self.F_Time.setText(_translate("Dialog", "Flight Time: 00:00:00"))
        self.F_TimeTextFormat = "Flight Time: %02d:%02d:%02d"
    # localIP를 업데이트해주는 함수입니다.
    def updateIP(self):
        ip = self.IPAddress.text() # UI에 적힌 텍스트를 가져와서
        self.tello.local_main_ip = ip # tello모듈의 멤버변수에 넣어줍니다.
        self.log('IP updated : %s' % ip) # 업데이트된 IP를 로깅합니다.
    # 움직임 값을 조절하는 방식이 바뀌었을 때 호출되는 함수입니다.
    def enable(self):
        if self.radioButton1.isChecked(): # 첫번째 방식이 체크되어있다면
            self.updateAll() # 앞뒤좌우로 움직이는 값을 업데이트해줍니다.
            self.Master_Spinbox.setEnabled(True) # 앞뒤좌우로 움직이는 값을 설정하는 UI를 킵니다.
            self.F_B_SpinBox.setEnabled(False) # 앞뒤로 움직이는 값을 설정하는 UI를 끕니다.
            self.L_R_Spinbox.setEnabled(False) # 좌우로 움직이는 값을 설정하는 UI를 끕니다.
        else:
            self.updateFB() # 좌우로 움직이는 값을 업데이트해줍니다.
            self.updateLR() # 앞뒤로 움직이는 값을 업데이트해줍니다.
            self.Master_Spinbox.setEnabled(False) # 앞뒤좌우로 움직이는 값을 설정하는 UI를 끕니다.
            self.F_B_SpinBox.setEnabled(True) # 앞뒤로 움직이는 값을 설정하는 UI를 킵니다.
            self.L_R_Spinbox.setEnabled(True) # 좌우로 움직이는 값을 설정하는 UI를 킵니다.
    # 좌우로 움직이는 값을 업데이트해주는 함수입니다.
    def updateLR(self):
        self.delta_LR = self.L_R_Spinbox.value() # 입력된 값을 가져옵니다.
    # 앞뒤로 움직이는 값을 업데이트해주는 함수입니다.
    def updateFB(self):
        self.delta_FB = self.F_B_SpinBox.value() # 입력된 값을 가져옵니다.
    # 앞뒤좌우로 움직이는 값을 업데이트해주는 함수입니다.
    def updateAll(self):
        self.delta_FB = self.Master_Spinbox.value() # 입력된 값을 가져옵니다.
        self.delta_LR = self.Master_Spinbox.value() # 입력된 값을 가져옵니다.
    # 회전하는 값을 업데이트해주는 함수입니다.
    def updateRotation(self):
        self.delta_rotate = self.Rotation_Spinbox.value() # 입력된 값을 가져옵니다.
    # 상하로 움직이는 값을 업데이트해주는 함수입니다.
    def updateHeight(self):
        self.delta_height = self.Height_Spinbox.value() # 입력된 값을 가져옵니다.
    # Tello드론과 연결을 시작하는 함수입니다.
    def connect(self):
        _translate = QtCore.QCoreApplication.translate
        if self.tello.tryConnect(): # tello모듈이 연결을 시도합니다. 성공하면
            self.Connect_M1.setText(_translate("Dialog", "DisConnect")) # 연결버튼의 이름을 연결해제로 변경합니다.
            self.Connect_M2.setText(_translate("Dialog", "DisConnect")) # 연결버튼의 이름을 연결해제로 변경합니다.
            self.Connect_M1.clicked.disconnect() # 연결버튼에게 바인딩된 함수를 제거합니다.
            self.Connect_M2.clicked.disconnect() # 연결버튼에게 바인딩된 함수를 제거합니다.
            self.Connect_M1.clicked.connect(self.disconnect) # 연결버튼에게 연결을 해제하는 함수를 바인딩합니다.
            self.Connect_M2.clicked.connect(self.disconnect) # 연결버튼에게 연결을 해제하는 함수를 바인딩합니다.
            self.button_on_off(True) # 드론을 조종하는 버튼들을 킵니다.
            self.log('connected')
        else: # 연결에 실패하면
            self.log("연결실패")
    # Tello드론과 연결을 해제하는 함수입니다.
    def disconnect(self):
        self.resetDetectionInfo() # 검출된 정보를 초기화합니다.
        _translate = QtCore.QCoreApplication.translate
        self.tello.disconnect() # tello 모듈이 연결을 해제합니다.
        self.Connect_M1.setText(_translate("Dialog", "Connect")) # 연결버튼의 이름을 연결로 변경합니다.
        self.Connect_M2.setText(_translate("Dialog", "Connect")) # 연결버튼의 이름을 연결로 변경합니다.
        self.Connect_M1.clicked.disconnect() # 연결버튼에게 바인딩된 함수를 제거합니다.
        self.Connect_M2.clicked.disconnect() # 연결버튼에게 바인딩된 함수를 제거합니다.
        self.Connect_M1.clicked.connect(self.connect) # 연결버튼에게 연결하는 함수를 바인딩합니다.
        self.Connect_M2.clicked.connect(self.connect) # 연결버튼에게 연결하는 함수를 바인딩합니다.
        self.videoimg.setPixmap(QtGui.QPixmap(":/Picture/sponsor.jpg")) # 드론이미지를 출력하던 곳을 기본이미지로 초기화합니다.
        self.button_on_off(False) # 드론을 조종하는 버튼들을 끕니다.
        self.log('disconnected')
    # 드론을 조종하기위한 버튼들을 켜거나 끌 수 있는 함수입니다. state로 true또는 false가 들어옵니다.)
    def button_on_off(self, state):
        # Forward 버튼들을 켜겨나 끕니다.
        self.Forward_M1.setEnabled(state)
        self.Forward_M2.setEnabled(state)
        # backward 버튼들을 켜겨나 끕니다.
        self.Backward_M1.setEnabled(state)
        self.Backward_M2.setEnabled(state)
        # left 버튼들을 켜겨나 끕니다.
        self.Left_M1.setEnabled(state)
        self.Left_M2.setEnabled(state)
        # right 버튼들을 켜겨나 끕니다.
        self.Right_M1.setEnabled(state)
        self.Right_M2.setEnabled(state)
        # Up 버튼들을 켜겨나 끕니다.
        self.Up_M1.setEnabled(state)
        self.Up_M2.setEnabled(state)
        # Down 버튼들을 켜겨나 끕니다.
        self.Down_M1.setEnabled(state)
        self.Down_M2.setEnabled(state)
        # CW 버튼들을 켜겨나 끕니다.
        self.CW_M1.setEnabled(state)
        self.CW_M2.setEnabled(state)
        # CCW 버튼들을 켜겨나 끕니다.
        self.CCW_M1.setEnabled(state)
        self.CCW_M2.setEnabled(state)
        # takeoff 버튼들을 켜겨나 끕니다.
        self.TakeOff_M1.setEnabled(state)
        self.TakeOff_M2.setEnabled(state)
        # snrCheck 버튼들을 켜겨나 끕니다.
        self.SNR_Check.setEnabled(state)
        self.SNR_Check.setEnabled(state)
    # 이륙버튼을 누르면 호출되는 함수입니다.
    def takeoff(self):
        if self.tello.socket is None: # 연결된 상태가 아니면 
            self.log("tello is not connected.")
            return # 리턴하여 함수를 종료합니다.
        cmd = "takeoff" # 이륙하는 Tello 명령어입니다.
        self.log(cmd)
        self.tello.send_command(cmd) # tello 모듈에게 명령어를 전달하도록 합니다.
    # 착륙버튼을 누르면 호출되는 함수입니다.
    def land(self):
        if self.tello.socket is None: # 연결된 상태가 아니면 
            self.log("tello is not connected.")
            return # 리턴하여 함수를 종료합니다.
        cmd = "land" # 착륙하는 Tello 명령어입니다.
        self.log(cmd)
        self.tello.send_command(cmd) # tello 모듈에게 명령어를 전달하도록 합니다.
    # 앞으로 이동버튼을 누르면 호출되는 함수입니다.
    def moveforward(self):
        if self.tello.socket is None: # 연결된 상태가 아니면 
            self.log("tello is not connected.")
            return # 리턴하여 함수를 종료합니다.
        cmd = "forward %d" % self.delta_FB # 마지막으로 설정된 값을 불러와 명령어를 완성합니다. 
        self.log(cmd)
        self.tello.send_command(cmd) # tello 모듈에게 명령어를 전달하도록 합니다.
    # 뒤로 이동버튼을 누르면 호출되는 함수입니다.
    def movebackward(self):
        if self.tello.socket is None: # 연결된 상태가 아니면 
            self.log("tello is not connected.")
            return # 리턴하여 함수를 종료합니다.
        cmd = "back %d" % self.delta_FB # 마지막으로 설정된 값을 불러와 명령어를 완성합니다. 
        self.log(cmd)
        self.tello.send_command(cmd) # tello 모듈에게 명령어를 전달하도록 합니다.
    # 왼쪽으로 이동버튼을 누르면 호출되는 함수입니다.
    def moveleft(self):
        if self.tello.socket is None: # 연결된 상태가 아니면 
            self.log("tello is not connected.")
            return # 리턴하여 함수를 종료합니다.
        cmd = "left %d" % self.delta_LR # 마지막으로 설정된 값을 불러와 명령어를 완성합니다. 
        self.log(cmd)
        self.tello.send_command(cmd) # tello 모듈에게 명령어를 전달하도록 합니다.
    # 오른쪽으로 이동버튼을 누르면 호출되는 함수입니다.
    def moveright(self):
        if self.tello.socket is None: # 연결된 상태가 아니면 
            self.log("tello is not connected.")
            return # 리턴하여 함수를 종료합니다.
        cmd = "right %d" % self.delta_LR # 마지막으로 설정된 값을 불러와 명령어를 완성합니다. 
        self.log(cmd)
        self.tello.send_command(cmd) # tello 모듈에게 명령어를 전달하도록 합니다.
    # 위로 이동버튼을 누르면 호출되는 함수입니다.
    def Up(self):
        if self.tello.socket is None: # 연결된 상태가 아니면 
            self.log("tello is not connected.")
            return # 리턴하여 함수를 종료합니다.
        cmd = "up %d" % self.delta_height # 마지막으로 설정된 값을 불러와 명령어를 완성합니다. 
        self.log(cmd)
        self.tello.send_command(cmd) # tello 모듈에게 명령어를 전달하도록 합니다.
    # 아래로 이동버튼을 누르면 호출되는 함수입니다.
    def Down(self):
        if self.tello.socket is None: # 연결된 상태가 아니면 
            self.log("tello is not connected.")
            return # 리턴하여 함수를 종료합니다.
        cmd = "down %d" % self.delta_height # 마지막으로 설정된 값을 불러와 명령어를 완성합니다. 
        self.log(cmd)
        self.tello.send_command(cmd) # tello 모듈에게 명령어를 전달하도록 합니다.
    # 시계방향으로 회전버튼을 누르면 호출되는 함수입니다.
    def rotateCW(self):
        if self.tello.socket is None: # 연결된 상태가 아니면 
            self.log("tello is not connected.")
            return # 리턴하여 함수를 종료합니다.
        cmd = "cw %d" % self.delta_rotate # 마지막으로 설정된 값을 불러와 명령어를 완성합니다. 
        self.log(cmd)
        self.tello.send_command(cmd) # tello 모듈에게 명령어를 전달하도록 합니다.
    # 반시계방향으로 회전버튼을 누르면 호출되는 함수입니다.
    def rotateCCW(self):
        if self.tello.socket is None: # 연결된 상태가 아니면 
            self.log("tello is not connected.")
            return # 리턴하여 함수를 종료합니다.
        cmd = "ccw %d" % self.delta_rotate # 마지막으로 설정된 값을 불러와 명령어를 완성합니다. 
        self.log(cmd)
        self.tello.send_command(cmd) # tello 모듈에게 명령어를 전달하도록 합니다.
    # check버튼을 누르면 호출되는 함수입니다.
    def check(self):
        if self.tello.socket is None: # 연결된 상태가 아니면 
            self.log("tello is not connected.")
            return
        self.requestSNR = True # 요청을 한 상태로 바꿉니다.
        cmd = "wifi?" # wifi 신호 대 잡음비(SNR) 상태를 요청하는 명령어입니다.
        self.log(cmd)
        self.tello.send_command(cmd) # tello 모듈에게 명령어를 전달하도록 합니다.
import Tello_rc

if __name__ == "__main__": # 이 파일이 main으로 python이 실행됐다면

    import sys
    try:
        if not os.path.exists('./captureResult'): # 캡쳐이미지를 저장할 디렉터리가 없으면
            os.makedirs('./captureResult') # 디렉터리를 만듭니다.
    except Exception as err:
        print('captureResult디렉토리 확인중에 문제가 발생했습니다.')
        print(err.__str__())
        
    if len(sys.argv) < 2: # 명령인수가 전달되지않았다면
        print("usage : python Tello_Gui_U_ver.py [True|False]")
        exit(0) # 프로그램을 종료합니다.
    if sys.argv[1] == "False": # 전달된 명령인수가 False면
        bObjectDetection =  False # 검출옵션에 False를 대입합니다.
    elif sys.argv[1] == "True": # 전달된 명령인수가 True면
        bObjectDetection = True # 검출옵션에 True를 대입합니다.
    else: # True나 False가 아닌 다른 것이 전달되면
        print("잘못된 매개변수 : %s"%sys.argv[1])
        exit(0) # 프로그램을 종료합니다.
        
    ### QT GUI를 시작하는 코드입니다.
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog(Dialog, 'CPU', bObjectDetection) # 추론하는데 사용하는 device를 GPU로 설정합니다.
    Dialog.show() # GUI를 보여줍니다.
    o = app.exec_() # GUI main loop가 시작됩니다.
    if ui.tello.cap is not None: # 프로그램이 종료되고 tello모듈의 VideoCapture가 Tello드론과 연결해제된 상태가 아니라면
        ui.tello.cap.release() # 연결해제합니다.
        print('cap release')
    sys.exit(o) # 프로그램을 종료합니다.